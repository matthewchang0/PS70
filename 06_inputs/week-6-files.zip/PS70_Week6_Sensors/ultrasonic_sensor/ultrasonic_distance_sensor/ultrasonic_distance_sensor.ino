#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

const int TRIG_PIN = D2;
const int ECHO_PIN = D3;

#define OLED_WIDTH  128
#define OLED_HEIGHT 64
#define OLED_ADDR   0x3C

class UltrasonicSensor {
  private:
    int trig_pin;
    int echo_pin;

  public:
    long duration = 0;

    UltrasonicSensor(int trig_pin, int echo_pin) {
      this->trig_pin = trig_pin;
      this->echo_pin = echo_pin;
    }

    void init() {
      pinMode(trig_pin, OUTPUT);
      pinMode(echo_pin, INPUT);
      digitalWrite(trig_pin, LOW);
    }

    long update() {

      digitalWrite(trig_pin, LOW);
      delayMicroseconds(2);
      digitalWrite(trig_pin, HIGH);
      delayMicroseconds(10);
      digitalWrite(trig_pin, LOW);

      long d = pulseIn(echo_pin, HIGH, 30000UL);
      if (d > 0) duration = d;
      return duration;
    }

    float distanceInches() {
      return duration * 0.01337f / 2.0f;
    }

    float distanceCm() {
      return duration * 0.0343f / 2.0f;
    }

    float distanceCalibrated() {
      float c1 = 0.0f;
      float c2 = 0.01337f / 2.0f;
      float c3 = 0.0f;
      float c4 = 0.0f;
      return c1 + c2 * duration + c3 * pow(duration, 2) + c4 * pow(duration, 3);
    }
};

UltrasonicSensor my_sensor(TRIG_PIN, ECHO_PIN);
Adafruit_SSD1306 display(OLED_WIDTH, OLED_HEIGHT, &Wire);

void setup() {
  Serial.begin(115200);
  Wire.begin();
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("SSD1306 allocation failed");
    while (true);
  }
  display.clearDisplay();
  display.display();
  my_sensor.init();
}

void loop() {
  my_sensor.update();
  float d_sos = my_sensor.distanceInches();
  float d_cal = my_sensor.distanceCalibrated();

  Serial.print("dur=");
  Serial.print(my_sensor.duration);
  Serial.print("us  sos=");
  Serial.print(d_sos, 2);
  Serial.print("in  cal=");
  Serial.print(d_cal, 2);
  Serial.println("in");

  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(WHITE);
  display.setCursor(0, 0);
  display.println("Sound:");
  display.print(d_sos, 2);
  display.println(" in");
  display.println("Calib:");
  display.print(d_cal, 2);
  display.println(" in");
  display.display();

  delay(60);
}
