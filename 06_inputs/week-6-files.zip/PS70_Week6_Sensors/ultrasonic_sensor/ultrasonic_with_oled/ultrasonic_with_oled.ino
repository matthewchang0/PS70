#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

const int TRIG_PIN = D2;
const int ECHO_PIN = D3;

const float US_PER_CM = 54.53913f;

#define OLED_WIDTH  128
#define OLED_HEIGHT 64
#define OLED_ADDR   0x3C
Adafruit_SSD1306 display(OLED_WIDTH, OLED_HEIGHT, &Wire);

const int SMOOTH_N = 5;
long buf[SMOOTH_N] = {0};
int buf_i = 0;

long readDuration() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  return pulseIn(ECHO_PIN, HIGH, 30000UL);
}

long smooth(long raw) {
  if (raw == 0) {

    long total = 0;
    for (int i = 0; i < SMOOTH_N; i++) total += buf[i];
    return total / SMOOTH_N;
  }
  buf[buf_i] = raw;
  buf_i = (buf_i + 1) % SMOOTH_N;
  long total = 0;
  for (int i = 0; i < SMOOTH_N; i++) total += buf[i];
  return total / SMOOTH_N;
}

float toCm(long duration) {
  return duration / US_PER_CM;
}

void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  digitalWrite(TRIG_PIN, LOW);

  Wire.begin();
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("SSD1306 init failed — check wiring and address");
    while (true) delay(1000);
  }
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("Starting...");
  display.display();

  for (int i = 0; i < SMOOTH_N; i++) {
    buf[i] = readDuration();
    delay(40);
  }
}

void loop() {
  long raw = readDuration();
  long avg = smooth(raw);
  float cm = toCm(avg);

  Serial.print(avg);
  Serial.print("\t");
  Serial.println(cm, 1);

  display.clearDisplay();

  display.setTextSize(3);
  display.setCursor(0, 8);
  display.print(cm, 1);
  display.setTextSize(2);
  display.print(" cm");

  display.setTextSize(1);
  display.setCursor(0, 52);
  display.print("time: ");
  display.print(avg);
  display.print(" us");

  display.display();
  delay(60);
}
