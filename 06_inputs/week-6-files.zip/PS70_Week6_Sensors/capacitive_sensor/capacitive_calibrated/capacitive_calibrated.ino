const int RX_PIN = D0;
const int TX_PIN = D6;
const int N_SAMPLES = 100;

const float C1 =  2514.66261f;
const float C2 = -0.164043f;
const float C3 =  0.00000267397f;

long readCapacitive() {
  long sum = 0;
  for (int i = 0; i < N_SAMPLES; i++) {
    digitalWrite(TX_PIN, HIGH);
    int high = analogRead(RX_PIN);
    delayMicroseconds(100);
    digitalWrite(TX_PIN, LOW);
    int low = analogRead(RX_PIN);
    sum += (high - low);
  }
  return sum;
}

float toGrams(long raw) {
  float r = (float)raw;
  float g = C1 + C2 * r + C3 * r * r;
  if (g < 0) g = 0;
  return g;
}

void setup() {
  Serial.begin(115200);
  pinMode(TX_PIN, OUTPUT);
  delay(500);
  Serial.println("raw\tgrams");
}

void loop() {
  long raw = readCapacitive();
  float grams = toGrams(raw);

  Serial.print(raw);
  Serial.print("\t");
  Serial.println(grams, 1);

  delay(100);
}
