#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

const int RX_PIN = D0;
const int TX_PIN = D6;
const int N_SAMPLES = 100;

const float C1 = -2486.85477f;
const float C2 =  0.0933895f;
const float C3 =  1.60704e-7f;

#define OLED_WIDTH  128
#define OLED_HEIGHT 64
#define OLED_ADDR   0x3C
Adafruit_SSD1306 display(OLED_WIDTH, OLED_HEIGHT, &Wire);

const int SMOOTH_N = 5;
long buf[SMOOTH_N] = {0};
int buf_i = 0;

long readCapacitive() {
  long sum = 0;
  for (int i = 0; i < N_SAMPLES; i++) {
    digitalWrite(TX_PIN, HIGH);
    int high = analogRead(RX_PIN);
    delayMicroseconds(100);
    digitalWrite(TX_PIN, LOW);
    int low = analogRead(RX_PIN);
    sum += (high - low);
  }
  return sum;
}

long smooth(long raw) {
  buf[buf_i] = raw;
  buf_i = (buf_i + 1) % SMOOTH_N;
  long total = 0;
  for (int i = 0; i < SMOOTH_N; i++) total += buf[i];
  return total / SMOOTH_N;
}

float toGrams(long raw) {
  float r = (float)raw;
  float g = C1 + C2 * r + C3 * r * r;
  if (g < 0) g = 0;
  return g;
}

void setup() {
  Serial.begin(115200);
  pinMode(TX_PIN, OUTPUT);
  Wire.begin();

  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("SSD1306 init failed — check wiring and address");
    while (true) delay(1000);
  }
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("Calibrating...");
  display.display();

  for (int i = 0; i < SMOOTH_N; i++) buf[i] = readCapacitive();
}

void loop() {
  long raw = readCapacitive();
  long avg = smooth(raw);
  float grams = toGrams(avg);

  Serial.print(avg);
  Serial.print("\t");
  Serial.println(grams, 1);

  display.clearDisplay();

  display.setTextSize(3);
  display.setCursor(0, 12);
  if (grams < 1000) {
    display.print((int)grams);
    display.setTextSize(2);
    display.print(" g");
  } else {
    display.print(grams / 1000.0f, 2);
    display.setTextSize(2);
    display.print(" kg");
  }

  display.setTextSize(1);
  display.setCursor(0, 54);
  display.print("raw=");
  display.print(avg);

  display.display();
  delay(50);
}
