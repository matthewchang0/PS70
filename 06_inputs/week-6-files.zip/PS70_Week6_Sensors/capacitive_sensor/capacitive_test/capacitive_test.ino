const int RX_PIN = D0;
const int TX_PIN = D6;
const int N_SAMPLES = 100;

long readCapacitive() {
  long sum = 0;
  for (int i = 0; i < N_SAMPLES; i++) {
    digitalWrite(TX_PIN, HIGH);
    int high = analogRead(RX_PIN);
    delayMicroseconds(100);
    digitalWrite(TX_PIN, LOW);
    int low = analogRead(RX_PIN);
    sum += (high - low);
  }
  return sum;
}

void setup() {
  Serial.begin(115200);
  pinMode(TX_PIN, OUTPUT);
  delay(500);
  Serial.println("Capacitive sensor test ready.");
}

void loop() {
  long value = readCapacitive();
  Serial.println(value);
  delay(50);
}
