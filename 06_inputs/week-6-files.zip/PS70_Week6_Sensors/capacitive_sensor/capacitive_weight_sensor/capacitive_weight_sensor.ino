#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

const int FORCE_SENSOR_ANALOG_PIN = D0;
const int FORCE_SENSOR_TX_PIN     = D6;

#define OLED_WIDTH  128
#define OLED_HEIGHT 64
#define OLED_ADDR   0x3C

class TxRxCapacitiveSensor {
  private:
    int analog_pin;
    int tx_pin;
    int n_samples;
    int read_high, read_low, diff;
    long sum;

  public:
    long result = 0;
    long previous_result = 0;

    TxRxCapacitiveSensor(int analog_pin, int tx_pin, int n_samples = 100) {
      this->analog_pin = analog_pin;
      this->tx_pin = tx_pin;
      this->n_samples = n_samples;
    }

    void init() {
      pinMode(tx_pin, OUTPUT);
    }

    long update() {
      sum = 0;
      for (int i = 0; i < n_samples; i++) {
        digitalWrite(tx_pin, HIGH);
        read_high = analogRead(analog_pin);
        delayMicroseconds(100);
        digitalWrite(tx_pin, LOW);
        read_low = analogRead(analog_pin);
        diff = read_high - read_low;
        sum += diff;
      }
      previous_result = result;
      result = sum;
      return sum;
    }

    float calculateWeight() {
      float c1 = 0.0;
      float c2 = 0.01;
      float c3 = 0.0;
      float c4 = 0.0;
      return c1 + c2 * result + c3 * pow(result, 2) + c4 * pow(result, 3);
    }
};

TxRxCapacitiveSensor force_sensor(FORCE_SENSOR_ANALOG_PIN, FORCE_SENSOR_TX_PIN);
Adafruit_SSD1306 display(OLED_WIDTH, OLED_HEIGHT, &Wire);

void setup() {
  Serial.begin(115200);
  Wire.begin();
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("SSD1306 allocation failed");
    while (true);
  }
  display.clearDisplay();
  display.display();
  force_sensor.init();
}

void loop() {
  long raw = force_sensor.update();
  float grams = force_sensor.calculateWeight();

  Serial.println(raw);

  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(WHITE);
  display.setCursor(0, 0);
  display.println("Weight:");
  display.print((int)grams);
  display.println(" g");
  display.setTextSize(1);
  display.setCursor(0, 50);
  display.print("raw=");
  display.print(raw);
  display.display();

  delay(50);
}
