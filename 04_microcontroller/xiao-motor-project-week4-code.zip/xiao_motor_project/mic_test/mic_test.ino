#include "driver/i2s.h"

#define I2S_BCLK D4
#define I2S_LRCL D5
#define I2S_DIN  D6
#define I2S_PORT I2S_NUM_0

void setupMic() {
  i2s_config_t cfg = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = 16000,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT,
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 4,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = false,
    .fixed_mclk = 0
  };
  i2s_pin_config_t pins = {
    .bck_io_num = I2S_BCLK,
    .ws_io_num  = I2S_LRCL,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num  = I2S_DIN
  };
  i2s_driver_install(I2S_PORT, &cfg, 0, NULL);
  i2s_set_pin(I2S_PORT, &pins);
}

void setup() {
  Serial.begin(115200);
  delay(500);
  setupMic();
  Serial.println("Mic ready. Make some noise!");
}

void loop() {
  int32_t buf[256];
  size_t got = 0;
  i2s_read(I2S_PORT, buf, sizeof(buf), &got, portMAX_DELAY);
  int samples = got / 4;
  if (samples == 0) return;

  long sum = 0;
  for (int i = 0; i < samples; i++) sum += (buf[i] >> 8);
  int32_t dc = sum / samples;

  int32_t peak = 0;
  long absSum = 0;
  for (int i = 0; i < samples; i++) {
    int32_t s = (buf[i] >> 8) - dc;
    int32_t a = abs(s);
    if (a > peak) peak = a;
    absSum += a;
  }
  int avg = (absSum / samples) / 256;
  int pk  = peak / 256;

  Serial.print("dc=");
  Serial.print(dc);
  Serial.print("  avg=");
  Serial.print(avg);
  Serial.print("  peak=");
  Serial.print(pk);
  Serial.print("  ");
  int bars = pk / 30;
  if (bars > 60) bars = 60;
  for (int i = 0; i < bars; i++) Serial.print("#");
  Serial.println();

  delay(50);
}
