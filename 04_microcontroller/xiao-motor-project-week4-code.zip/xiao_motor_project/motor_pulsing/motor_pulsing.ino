#define IN1 D1
#define IN2 D2
#define ENA D3

const int PULSE_MS = 80;    // length of each pulse 
const int REST_MS  = 400;   // gap between pulses 

void setup() {
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(ENA, OUTPUT);

  digitalWrite(IN1, HIGH);  
  digitalWrite(IN2, LOW);
}

void loop() {
  analogWrite(ENA, 255);   
  delay(PULSE_MS);

  analogWrite(ENA, 0);      
  delay(REST_MS);
}
