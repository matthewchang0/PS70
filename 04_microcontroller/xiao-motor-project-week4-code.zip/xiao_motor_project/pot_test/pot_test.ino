#define POT A0

void setup() {
  Serial.begin(115200);
}

void loop() {
  int raw = analogRead(POT);
  int speed = map(raw, 0, 4095, 0, 255);

  Serial.print("raw=");
  Serial.print(raw);
  Serial.print("  speed=");
  Serial.println(speed);

  delay(100);
}
