#define IN1 D1
#define IN2 D2
#define ENA D3
#define POT A0

void setup() {
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(ENA, OUTPUT);

  digitalWrite(IN1, HIGH); 
  digitalWrite(IN2, LOW);
}

void loop() {
  int raw = analogRead(POT);
  int speed = map(raw, 0, 4095, 0, 255);
  analogWrite(ENA, speed);
}
