#define IN1 D1
#define IN2 D2
#define ENA D3

void setup() {
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(ENA, OUTPUT);

  digitalWrite(IN1, HIGH);  
  digitalWrite(IN2, LOW);
  digitalWrite(ENA, HIGH);  
}

void loop() {
  // nothing
}
