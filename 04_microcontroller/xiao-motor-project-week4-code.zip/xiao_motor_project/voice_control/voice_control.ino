#include <WiFi.h>
#include <WiFiClientSecure.h>
#include "driver/i2s.h"

const char* WIFI_SSID  = 
const char* WIFI_PASS  = 
const char* OPENAI_KEY = 

#define IN1  D1
#define IN2  D2
#define ENA  D3
#define POT  A0
#define I2S_BCLK D4
#define I2S_LRCL D5
#define I2S_DIN  D6
#define I2S_PORT I2S_NUM_0

const int   SAMPLE_RATE     = 16000;
const float REC_SECONDS     = 1.5f;
const int   REC_SAMPLES     = (int)(SAMPLE_RATE * REC_SECONDS);
const int   REC_BYTES       = REC_SAMPLES * 2;

int16_t* audio   = nullptr;  
int32_t* rawBuf  = nullptr;  
bool     motorOn = false;

void setupMic() {
  i2s_config_t cfg = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT,
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 4,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = false,
    .fixed_mclk = 0
  };
  i2s_pin_config_t pins = {
    .bck_io_num = I2S_BCLK,
    .ws_io_num  = I2S_LRCL,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num  = I2S_DIN
  };
  i2s_driver_install(I2S_PORT, &cfg, 0, NULL);
  i2s_set_pin(I2S_PORT, &pins);
}

int readRaw(int32_t* raw, int count) {
  size_t got = 0;
  i2s_read(I2S_PORT, raw, count * 4, &got, portMAX_DELAY);
  return got / 4;
}

int peakAmp(int32_t* raw, int n) {
  long sum = 0;
  for (int i = 0; i < n; i++) sum += (raw[i] >> 8);
  int32_t dc = sum / n;
  int32_t peak = 0;
  for (int i = 0; i < n; i++) {
    int32_t a = abs((raw[i] >> 8) - dc);
    if (a > peak) peak = a;
  }
  return peak / 256;
}


bool voiceDetected() {
  int32_t raw[128];
  int n = readRaw(raw, 128);
  if (n == 0) return false;
  return peakAmp(raw, n) > VOICE_THRESHOLD;
}

void recordAudio() {
  static int32_t chunk[256];

  int written = 0;
  while (written < REC_SAMPLES) {
    int want = min(256, REC_SAMPLES - written);
    int n = readRaw(chunk, want);
    memcpy(rawBuf + written, chunk, n * 4);
    written += n;
  }

  long sum = 0;
  for (int i = 0; i < REC_SAMPLES; i++) sum += (rawBuf[i] >> 8);
  int32_t dc = sum / REC_SAMPLES;

  int32_t rawPeak = 0;
  for (int i = 0; i < REC_SAMPLES; i++) {
    int32_t a = abs((rawBuf[i] >> 8) - dc);
    if (a > rawPeak) rawPeak = a;
  }

  float scale = (rawPeak > 0) ? (25000.0f / rawPeak) : 1.0f;
  if (scale > 200.0f) scale = 200.0f;

  int32_t maxSeen = 0;
  for (int i = 0; i < REC_SAMPLES; i++) {
    int32_t v = (rawBuf[i] >> 8) - dc;
    int32_t s = (int32_t)(v * scale);
    if (s >  32767) s =  32767;
    if (s < -32768) s = -32768;
    audio[i] = (int16_t)s;
    int32_t a = abs(s);
    if (a > maxSeen) maxSeen = a;
  }
  Serial.printf("rawPeak=%ld scale=%.2f finalPeak=%ld\n", rawPeak, scale, maxSeen);
}

void writeWavHeader(uint8_t* h, int dataLen) {
  int fileLen = dataLen + 36, br = SAMPLE_RATE * 2;
  memcpy(h, "RIFF", 4);
  h[4]=fileLen; h[5]=fileLen>>8; h[6]=fileLen>>16; h[7]=fileLen>>24;
  memcpy(h+8, "WAVE", 4); memcpy(h+12, "fmt ", 4);
  h[16]=16; h[17]=0; h[18]=0; h[19]=0;
  h[20]=1;  h[21]=0;  h[22]=1;  h[23]=0;
  h[24]=SAMPLE_RATE; h[25]=SAMPLE_RATE>>8; h[26]=SAMPLE_RATE>>16; h[27]=SAMPLE_RATE>>24;
  h[28]=br; h[29]=br>>8; h[30]=br>>16; h[31]=br>>24;
  h[32]=2; h[33]=0; h[34]=16; h[35]=0;
  memcpy(h+36, "data", 4);
  h[40]=dataLen; h[41]=dataLen>>8; h[42]=dataLen>>16; h[43]=dataLen>>24;
}

String transcribe() {
  WiFiClientSecure client;
  client.setInsecure();
  if (!client.connect("api.openai.com", 443)) {
    Serial.println("connect fail");
    return "";
  }

  const char* b = "----XIAOMotorVoice";

  String head =
    "--" + String(b) + "\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\ngpt-4o-transcribe\r\n"
    "--" + String(b) + "\r\nContent-Disposition: form-data; name=\"response_format\"\r\n\r\ntext\r\n"
    "--" + String(b) + "\r\nContent-Disposition: form-data; name=\"language\"\r\n\r\nen\r\n"
    "--" + String(b) + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.wav\"\r\n"
                       "Content-Type: audio/wav\r\n\r\n";
  String tail = "\r\n--" + String(b) + "--\r\n";

  uint8_t wav[44];
  writeWavHeader(wav, REC_BYTES);
  int len = head.length() + 44 + REC_BYTES + tail.length();

  client.printf("POST /v1/audio/transcriptions HTTP/1.1\r\n");
  client.printf("Host: api.openai.com\r\n");
  client.printf("Authorization: Bearer %s\r\n", OPENAI_KEY);
  client.printf("Content-Type: multipart/form-data; boundary=%s\r\n", b);
  client.printf("Content-Length: %d\r\n", len);
  client.printf("Connection: close\r\n\r\n");

  client.print(head);
  client.write(wav, 44);
  int sent = 0;
  while (sent < REC_BYTES) {
    int n = min(1024, REC_BYTES - sent);
    client.write((uint8_t*)audio + sent, n);
    sent += n;
  }
  client.print(tail);

  String body = "";
  bool inBody = false;
  unsigned long t = millis();
  while (millis() - t < 15000 && (client.connected() || client.available())) {
    if (!client.available()) { delay(10); continue; }
    String line = client.readStringUntil('\n');
    if (!inBody) { if (line.length() <= 1) inBody = true; }
    else         { body += line; }
    t = millis();
  }
  client.stop();
  body.trim();
  return body;
}

bool isCommand(String& text, const char* cmd) {
  String clean = "";
  for (int i = 0; i < text.length(); i++) {
    char c = text[i];
    if (isalpha(c)) clean += (char)tolower(c);
  }
  return clean == cmd;
}

void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT); pinMode(ENA, OUTPUT);
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);   // direction: forward
  analogWrite(ENA, 0);

  Serial.printf("WiFi: %s", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) { delay(400); Serial.print("."); }
  Serial.printf("\nIP %s\n", WiFi.localIP().toString().c_str());

  setupMic();

  int32_t junk[256];
  for (int i = 0; i < 30; i++) readRaw(junk, 256);


  audio  = (int16_t*)malloc(REC_BYTES);
  if (!audio)  { Serial.println("audio OOM");  while (1) delay(1000); }
  rawBuf = (int32_t*)malloc(REC_SAMPLES * 4);
  if (!rawBuf) { Serial.println("rawBuf OOM"); while (1) delay(1000); }

  Serial.println("Ready. Say \"start\" or \"stop\".");
}

void loop() {

  int speed = map(analogRead(POT), 0, 4095, 0, 255);
  analogWrite(ENA, motorOn ? speed : 0);

  if (voiceDetected()) {
    Serial.println(">>> recording");
    recordAudio();
    Serial.println(">>> uploading");
    String text = transcribe();
    text.toLowerCase();
    Serial.printf(">>> heard: \"%s\"\n", text.c_str());

    if      (isCommand(text, "start")) { motorOn = true;  Serial.println("MOTOR ON");  }
    else if (isCommand(text, "stop"))  { motorOn = false; Serial.println("MOTOR OFF"); }
    delay(400); 
  }
}
