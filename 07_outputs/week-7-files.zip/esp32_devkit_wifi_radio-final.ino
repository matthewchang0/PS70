#include <WiFi.h>
#include <Wire.h>
#include <Audio.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

const char* WIFI_SSID = "";
const char* WIFI_PASS = "";

#define POT_PIN    34
#define ENC_A      32
#define ENC_B      33
#define ENC_BTN    23
#define I2C_SDA    21
#define I2C_SCL    22
#define I2S_BCLK   27
#define I2S_LRC    26
#define I2S_DOUT   25

#define SCREEN_W 128
#define SCREEN_H 64

struct Station { const char* name; const char* url; };
const Station STATIONS[] = {
  { "SomaFM Groove Salad", "http://ice1.somafm.com/groovesalad-128-mp3" },
  { "SomaFM Indie Pop",    "http://ice1.somafm.com/indiepop-128-mp3"    },
  { "Radio Paradise Main", "http://stream.radioparadise.com/mp3-128"    },
  { "KEXP Seattle",        "http://live-mp3-128.kexp.org/kexp128.mp3"   },
  { "BBC World Service",   "http://stream.live.vc.bbcmedia.co.uk/bbc_world_service" }
};
const int NUM_STATIONS = sizeof(STATIONS) / sizeof(STATIONS[0]);

// polled, debounced rotary encoder
class RotaryEncoder {
  public:
    RotaryEncoder(int pinA, int pinB, unsigned long debounceMs)
      : _pinA(pinA), _pinB(pinB), _debounceMs(debounceMs),
        _lastA(HIGH), _lastEdgeMs(0), _count(0), _reported(0) {}

    void begin() {
      pinMode(_pinA, INPUT_PULLUP);
      pinMode(_pinB, INPUT_PULLUP);
      _lastA = digitalRead(_pinA);
    }

    // call every loop
    void poll() {
      int a = digitalRead(_pinA);
      if (_lastA == HIGH && a == LOW) {
        unsigned long now = millis();
        if (now - _lastEdgeMs > _debounceMs) {
          _lastEdgeMs = now;
          if (digitalRead(_pinB) == LOW) _count--;
          else                          _count++;
        }
      }
      _lastA = a;
    }

    // net detents since the previous call
    long delta() {
      long d = _count - _reported;
      _reported = _count;
      return d;
    }

  private:
    int _pinA, _pinB;
    unsigned long _debounceMs;
    int _lastA;
    unsigned long _lastEdgeMs;
    long _count, _reported;
};

// audio, display, encoder and all radio state
class Radio {
  public:
    Radio()
      : _display(SCREEN_W, SCREEN_H, &Wire, -1),
        _encoder(ENC_A, ENC_B, 30),
        _state(CONNECTING), _station(0), _volume(10), _playing(true),
        _lastPotMs(0), _lastBtnMs(0), _lastDrawMs(0) {
      _title[0] = '\0';
    }

    void begin() {
      pinMode(ENC_BTN, INPUT_PULLUP);
      _encoder.begin();

      Wire.begin(I2C_SDA, I2C_SCL);
      Wire.setClock(400000);
      _display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
      showMessage("Connecting WiFi...");

      WiFi.mode(WIFI_STA);
      WiFi.begin(WIFI_SSID, WIFI_PASS);   // returns immediately
    }

    // call every loop
    void update() {
      if (_state == CONNECTING) {
        if (WiFi.status() == WL_CONNECTED) {
          _audio.setPinout(I2S_BCLK, I2S_LRC, I2S_DOUT);
          _audio.setVolume(_volume);
          startStation(_station);
          _state = RUNNING;
        }
        return;
      }

      _audio.loop();
      _encoder.poll();
      serviceVolume();

      long d = _encoder.delta();
      if (d != 0) changeStation(d);

      serviceButton();

      if (millis() - _lastDrawMs > 500) draw();
    }

    void onStreamTitle(const char* info) {
      strncpy(_title, info, sizeof(_title) - 1);
      _title[sizeof(_title) - 1] = '\0';
      draw();
    }

  private:
    enum State { CONNECTING, RUNNING };

    void changeStation(int steps) {
      int n = NUM_STATIONS;
      startStation(((_station + steps) % n + n) % n);
    }

    void startStation(int idx) {
      _station = idx;
      _audio.stopSong();
      _title[0] = '\0';
      _playing = true;
      draw();                              // redo before the slow connect
      _audio.connecttohost(STATIONS[idx].url);
    }

    void togglePlay() {
      _playing = !_playing;
      draw();
      if (_playing) _audio.connecttohost(STATIONS[_station].url);
      else          _audio.stopSong();
    }

    // volume potentiometer, sampled every 80ms
    void serviceVolume() {
      if (millis() - _lastPotMs < 80) return;
      _lastPotMs = millis();
      int raw = analogRead(POT_PIN);
      int v = map(constrain(raw, 150, 3900), 150, 3900, 21, 0);
      if (v != _volume) {
        _volume = v;
        _audio.setVolume(_volume);
        draw();
      }
    }

    // play/pause button
    void serviceButton() {
      if (digitalRead(ENC_BTN) == LOW && millis() - _lastBtnMs > 300) {
        _lastBtnMs = millis();
        togglePlay();
      }
    }

    void showMessage(const char* msg) {
      _display.clearDisplay();
      _display.setTextColor(SSD1306_WHITE);
      _display.setTextSize(1);
      _display.setCursor(0, 0);
      _display.println("WiFi Radio");
      _display.setCursor(0, 20);
      _display.println(msg);
      _display.display();
    }

    void draw() {
      _lastDrawMs = millis();
      _display.clearDisplay();
      _display.setTextSize(1);
      _display.setTextColor(SSD1306_WHITE);

      // top bar: play state, station index, WiFi signal
      _display.setCursor(0, 0);
      _display.print(_playing ? "> " : "|| ");
      _display.print(_station + 1);
      _display.print("/");
      _display.print(NUM_STATIONS);
      _display.setCursor(86, 0);
      _display.print(WiFi.RSSI());
      _display.print("dB");
      _display.drawLine(0, 10, 128, 10, SSD1306_WHITE);

      // station name
      _display.setCursor(0, 14);
      _display.print(clip(STATIONS[_station].name));

      // now-playing track
      if (_title[0]) {
        _display.setCursor(0, 28);
        _display.print(clip(_title));
      }

      // volume bar
      _display.setCursor(0, 52);
      _display.print("Vol");
      _display.drawRect(24, 52, 100, 8, SSD1306_WHITE);
      _display.fillRect(24, 52, (_volume * 100) / 21, 8, SSD1306_WHITE);

      _display.display();
    }

    // truncate to one display line
    const char* clip(const char* s) {
      static char buf[22];
      strncpy(buf, s, 21);
      buf[21] = '\0';
      return buf;
    }

    Adafruit_SSD1306 _display;
    Audio            _audio;
    RotaryEncoder    _encoder;

    State _state;
    int   _station;
    int   _volume;
    bool  _playing;
    char  _title[64];
    unsigned long _lastPotMs, _lastBtnMs, _lastDrawMs;
};

Radio radio;

// Audio library callbacks
void audio_showstreamtitle(const char* info) { radio.onStreamTitle(info); }
void audio_info(const char* info) { Serial.print("info: "); Serial.println(info); }

void setup() {
  Serial.begin(115200);
  radio.begin();
}

void loop() {
  radio.update();
}
