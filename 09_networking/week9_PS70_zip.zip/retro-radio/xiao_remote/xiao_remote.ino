#include <esp_now.h>
#include <WiFi.h>
#include "esp_wifi.h"
#include <Adafruit_NeoPixel.h>

uint8_t mainRadioMac[] = { 0x34, 0x5F, 0x45, 0x37, 0x17, 0x4C };

#define ENC_CLK   2
#define ENC_DT    3
#define ENC_SW    4
#define BTN_NEXT  5
#define BTN_MODE  6
#define BTN_PREV  7
#define BTN_MUTE  21
#define LED_PIN   10

#define NUM_PIXELS 10
Adafruit_NeoPixel pixels(NUM_PIXELS, LED_PIN, NEO_GRB + NEO_KHZ800);

struct RemotePacket { uint8_t cmd; };
#define CMD_PLAY  1
#define CMD_VOLUP 2
#define CMD_VOLDN 3
#define CMD_NEXT  4
#define CMD_MODE  5
#define CMD_PREV  6
#define CMD_MUTE  7

struct StatePacket {
  uint8_t mode;
  uint8_t volumePct;
  uint8_t paused;
  uint8_t muted;
  char    name[40];
};
StatePacket lastState;
bool haveState = false;
uint8_t displayedMode = 255;

volatile int encoderDelta = 0;
volatile unsigned long lastEncIRQ = 0;
bool lastEncSwState = HIGH, lastNextState = HIGH, lastModeState = HIGH;
bool lastPrevState = HIGH, lastMuteState = HIGH;
unsigned long lastEncSwChange = 0, lastNextChange = 0, lastModeChange = 0;
unsigned long lastPrevChange = 0, lastMuteChange = 0;

volatile bool lastSendAcked = false;
volatile bool ackReceived = false;
uint8_t currentChannel = 1;

void IRAM_ATTR onEncoderTurn() {
  unsigned long now = millis();
  if (now - lastEncIRQ < 2) return;
  lastEncIRQ = now;
  if (digitalRead(ENC_DT) == digitalRead(ENC_CLK)) encoderDelta--;
  else encoderDelta++;
}

void updateLedForMode(uint8_t mode) {
  uint8_t r = 0, g = 0, b = 0;
  switch (mode) {
    case 0: r = 128; g =   0; b = 200; break;
    case 1: r =   0; g =  60; b = 255; break;
    case 2: r =   0; g = 200; b =  80; break;
    case 3: r = 255; g = 140; b =   0; break;
    default: r = 30; g = 30; b = 30; break;
  }
  for (int i = 0; i < NUM_PIXELS; i++) pixels.setPixelColor(i, pixels.Color(r, g, b));
  pixels.show();
  displayedMode = mode;
}

void onDataSent(const uint8_t* mac, esp_now_send_status_t status) {
  lastSendAcked = (status == ESP_NOW_SEND_SUCCESS);
  ackReceived = true;
}

void onDataRecv(const uint8_t* mac, const uint8_t* data, int len) {
  if (len == sizeof(StatePacket)) {
    memcpy(&lastState, data, sizeof(StatePacket));
    haveState = true;
    if (lastState.mode != displayedMode) updateLedForMode(lastState.mode);
    const char* modeName = (lastState.mode == 0) ? "MP3"
                         : (lastState.mode == 1) ? "BT"
                         : (lastState.mode == 2) ? "RADIO" : "FM";
    Serial.print("State: ");
    Serial.print(modeName);
    Serial.print("  vol=");
    Serial.print(lastState.volumePct);
    Serial.print(lastState.muted ? " MUTED" : "");
    Serial.print(lastState.paused ? " PAUSED" : "");
    Serial.print("  now=");
    Serial.println(lastState.name);
  }
}

void setChannel(uint8_t ch) {
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);
  currentChannel = ch;
}

bool sendWithChannelScan(uint8_t cmd) {
  RemotePacket pkt = { cmd };
  ackReceived = false;
  esp_now_send(mainRadioMac, (uint8_t*)&pkt, sizeof(pkt));
  unsigned long t0 = millis();
  while (!ackReceived && millis() - t0 < 80) delay(1);
  if (lastSendAcked) return true;

  Serial.print("  scanning");
  for (uint8_t ch = 1; ch <= 13; ch++) {
    if (ch == currentChannel) continue;
    setChannel(ch);
    Serial.print(".");
    ackReceived = false;
    esp_now_send(mainRadioMac, (uint8_t*)&pkt, sizeof(pkt));
    unsigned long t1 = millis();
    while (!ackReceived && millis() - t1 < 80) delay(1);
    if (lastSendAcked) { Serial.print(" found ch "); Serial.println(ch); return true; }
  }
  Serial.println(" radio unreachable");
  return false;
}

void send(uint8_t cmd, const char* name) {
  Serial.print("Send "); Serial.print(name);
  if (sendWithChannelScan(cmd)) Serial.println("  delivered");
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  pixels.begin();
  pixels.setBrightness(60);
  pixels.clear();
  pixels.show();

  pinMode(ENC_CLK,  INPUT_PULLUP);
  pinMode(ENC_DT,   INPUT_PULLUP);
  pinMode(ENC_SW,   INPUT_PULLUP);
  pinMode(BTN_NEXT, INPUT_PULLUP);
  pinMode(BTN_MODE, INPUT_PULLUP);
  pinMode(BTN_PREV, INPUT_PULLUP);
  pinMode(BTN_MUTE, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENC_CLK), onEncoderTurn, FALLING);

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(100);
  setChannel(1);

  Serial.print("XIAO MAC: ");
  Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init failed");
    while (1) delay(1000);
  }
  esp_now_register_send_cb(onDataSent);
  esp_now_register_recv_cb(onDataRecv);

  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, mainRadioMac, 6);
  peer.channel = 0;
  peer.encrypt = false;
  if (esp_now_add_peer(&peer) != ESP_OK) {
    Serial.println("Add peer failed");
    while (1) delay(1000);
  }

  Serial.println("Remote ready -- waiting for state from radio");
}

void loop() {
  if (encoderDelta != 0) {
    noInterrupts();
    int delta = encoderDelta;
    encoderDelta = 0;
    interrupts();
    if (delta > 0) for (int i = 0; i < delta; i++) send(CMD_VOLUP, "VOL+");
    else for (int i = 0; i < -delta; i++) send(CMD_VOLDN, "VOL-");
  }

  bool encSw = digitalRead(ENC_SW);
  if (encSw != lastEncSwState && (millis() - lastEncSwChange) > 50) {
    lastEncSwChange = millis();
    if (encSw == LOW && lastEncSwState == HIGH) send(CMD_PLAY, "PLAY");
    lastEncSwState = encSw;
  }

  bool nextBtn = digitalRead(BTN_NEXT);
  if (nextBtn != lastNextState && (millis() - lastNextChange) > 50) {
    lastNextChange = millis();
    if (nextBtn == LOW && lastNextState == HIGH) send(CMD_NEXT, "NEXT");
    lastNextState = nextBtn;
  }

  bool modeBtn = digitalRead(BTN_MODE);
  if (modeBtn != lastModeState && (millis() - lastModeChange) > 50) {
    lastModeChange = millis();
    if (modeBtn == LOW && lastModeState == HIGH) send(CMD_MODE, "MODE");
    lastModeState = modeBtn;
  }

  bool prevBtn = digitalRead(BTN_PREV);
  if (prevBtn != lastPrevState && (millis() - lastPrevChange) > 50) {
    lastPrevChange = millis();
    if (prevBtn == LOW && lastPrevState == HIGH) send(CMD_PREV, "PREV");
    lastPrevState = prevBtn;
  }

  bool muteBtn = digitalRead(BTN_MUTE);
  if (muteBtn != lastMuteState && (millis() - lastMuteChange) > 50) {
    lastMuteChange = millis();
    if (muteBtn == LOW && lastMuteState == HIGH) send(CMD_MUTE, "MUTE");
    lastMuteState = muteBtn;
  }

  delay(5);
}
