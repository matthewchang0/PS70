#define USE_LEGACY_I2S 1

#include <SD.h>
#include <SPI.h>
#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <esp_now.h>
#include <math.h>
#include <U8g2lib.h>
#include "AudioTools.h"
#include "AudioTools/AudioCodecs/CodecMP3Helix.h"
#include "BluetoothA2DPSink.h"
#include "driver/i2s.h"
#include "driver/adc.h"
#include "esp_task_wdt.h"

const char* WIFI_SSID = "MAKERSPACE";
const char* WIFI_PASS = "12345678";

uint8_t xiaoMac[] = { 0xB0, 0xA6, 0x04, 0x06, 0xAF, 0x44 };

#define CMD_PLAY  1
#define CMD_VOLUP 2
#define CMD_VOLDN 3
#define CMD_NEXT  4
#define CMD_MODE  5
#define CMD_PREV  6
#define CMD_MUTE  7

#define SD_CS    5
#define I2S_BCLK 13
#define I2S_LRC  14
#define I2S_DIN  12
#define ENC_CLK  27
#define ENC_DT   26
#define ENC_SW   25
#define BTN_MP3    32
#define BTN_BT     33
#define BTN_RADIO  17
#define BTN_PAIR   15
#define BTN_MUTE   4
#define BTN_PREV   16
#define BTN_NEXT   2
#define OLED_SDA 21
#define OLED_SCL 22
#define FM_ADC_CHANNEL  ADC1_CHANNEL_7
#define TEA5767_ADDR    0x60
#define FM_SAMPLE_RATE  16000

enum Mode { MODE_MP3 = 0, MODE_BT = 1, MODE_RADIO = 2, MODE_FM = 3 };
Mode currentMode = MODE_MP3;

Preferences prefs;
U8G2_SSD1306_128X64_NONAME_F_HW_I2C display(U8G2_R0, U8X8_PIN_NONE);

I2SStream i2s;
I2SConfig i2sCfg;
VolumeStream volume(i2s);
EncodedAudioStream decoder(&volume, new MP3DecoderHelix());
File audioFile;
StreamCopy copier(decoder, audioFile, 4096);
BluetoothA2DPSink a2dp_sink(i2s);

struct Station { const char* name; const char* url; };
Station stations[] = {
  { "WHRB 95.3 Harvard",   "http://stream.whrb.org:8000/whrb-mp3" },
  { "WBUR 90.9 NPR",       "https://icecast-stream.wbur.org/wbur_www" },
  { "KUSC 91.5 Classical", "https://playerservices.streamtheworld.com/api/livestream-redirect/KUSCMP128.mp3" },
  { "SomaFM Groove Salad", "http://ice1.somafm.com/groovesalad-128-mp3" },
  { "SomaFM Indie Pop",    "http://ice1.somafm.com/indiepop-128-mp3" },
  { "SomaFM Drone Zone",   "http://ice1.somafm.com/dronezone-128-mp3" },
  { "SomaFM Deep Space",   "http://ice1.somafm.com/deepspaceone-128-mp3" },
  { "SomaFM Lush",         "http://ice1.somafm.com/lush-128-mp3" },
};
const int NUM_STATIONS = sizeof(stations) / sizeof(stations[0]);
int currentStation = 0;
WiFiClient radioClient;
HTTPClient radioHttp;
bool radioConnected = false;
uint8_t radioBuf[1024];

float fmFrequencyMHz = 90.9f;
volatile int fmVolumeQ7 = 96;
volatile bool fmMuted = false;
TaskHandle_t fmAudioTaskHandle = NULL;

String tracks[32];
int trackCount = 0;
int currentTrack = -1;
bool paused = false;
bool muted = false;
float vol = 0.5;

volatile int encoderDelta = 0;
volatile unsigned long lastEncIRQ = 0;
bool lastEncBtnState = HIGH;
unsigned long lastEncBtnChange = 0;

volatile bool connectEvent = false;
volatile bool disconnectEvent = false;
bool discoverable = false;
unsigned long lastBeep = 0;
#define BEEP_INTERVAL 1500

unsigned long lastDisplayRefresh = 0;
#define DISPLAY_REFRESH_MS 250
unsigned long lastStackCheck = 0;
#define STACK_CHECK_MS 5000

volatile uint8_t pendingRemoteCmd = 0;

struct StatePacket {
  uint8_t mode;
  uint8_t volumePct;
  uint8_t paused;
  uint8_t muted;
  char    name[40];
};
unsigned long lastStateBroadcast = 0;
#define STATE_BROADCAST_MS 3000

WebServer webServer(80);
bool webServerRunning = false;

struct Button { int pin; bool lastState; unsigned long lastChange; const char* name; };
Button buttons[] = {
  { BTN_MP3, HIGH, 0, "MP3" }, { BTN_BT, HIGH, 0, "BT" },
  { BTN_RADIO, HIGH, 0, "RADIO" }, { BTN_PAIR, HIGH, 0, "PAIR" },
  { BTN_MUTE, HIGH, 0, "MUTE" }, { BTN_PREV, HIGH, 0, "PREV" },
  { BTN_NEXT, HIGH, 0, "NEXT" },
};
const int NUM_BUTTONS = sizeof(buttons) / sizeof(buttons[0]);

void IRAM_ATTR onEncoderTurn() {
  unsigned long now = millis();
  if (now - lastEncIRQ < 2) return;
  lastEncIRQ = now;
  if (digitalRead(ENC_DT) == digitalRead(ENC_CLK)) encoderDelta--;
  else encoderDelta++;
}

void onConnectionStateChanged(esp_a2d_connection_state_t state, void* obj) {
  if (state == ESP_A2D_CONNECTION_STATE_CONNECTED) connectEvent = true;
  else if (state == ESP_A2D_CONNECTION_STATE_DISCONNECTED) disconnectEvent = true;
}

void btSendPassthrough(uint8_t cmd) {
  esp_avrc_ct_send_passthrough_cmd(0, cmd, ESP_AVRC_PT_CMD_STATE_PRESSED);
  esp_avrc_ct_send_passthrough_cmd(0, cmd, ESP_AVRC_PT_CMD_STATE_RELEASED);
}

void onEspNowRecv(const uint8_t* mac, const uint8_t* data, int len) {
  if (len < 1) return;
  pendingRemoteCmd = data[0];
}

void setupEspNow() {
  if (esp_now_init() != ESP_OK) { Serial.println("ESP-NOW init failed"); return; }
  esp_now_register_recv_cb(onEspNowRecv);
  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, xiaoMac, 6);
  peer.channel = 0;
  peer.encrypt = false;
  esp_now_add_peer(&peer);
  Serial.println("ESP-NOW receiver ready");
}

void broadcastState() {
  StatePacket pkt;
  pkt.mode = (uint8_t)currentMode;
  if (currentMode == MODE_FM) {
    pkt.volumePct = (fmVolumeQ7 * 100) / 128;
    pkt.muted = fmMuted ? 1 : 0;
    pkt.paused = 0;
  } else {
    pkt.volumePct = (uint8_t)(vol * 100);
    pkt.muted = muted ? 1 : 0;
    pkt.paused = paused ? 1 : 0;
  }
  memset(pkt.name, 0, sizeof(pkt.name));
  String n = "";
  if (currentMode == MODE_MP3 && currentTrack >= 0 && currentTrack < trackCount) {
    n = tracks[currentTrack];
    if (n.startsWith("/")) n = n.substring(1);
  } else if (currentMode == MODE_RADIO) {
    n = stations[currentStation].name;
  } else if (currentMode == MODE_BT) {
    n = a2dp_sink.is_connected() ? "Connected" : "Ready";
  } else if (currentMode == MODE_FM) {
    char buf[16]; snprintf(buf, sizeof(buf), "%.1f MHz", fmFrequencyMHz); n = buf;
  }
  strncpy(pkt.name, n.c_str(), sizeof(pkt.name) - 1);
  esp_now_send(xiaoMac, (uint8_t*)&pkt, sizeof(pkt));
  lastStateBroadcast = millis();
}

void playBeep() {
  const int sr = 44100;
  int samples = sr * 200 / 1000;
  for (int i = 0; i < samples; i++) {
    float t = (float)i / sr;
    int16_t s = sin(2 * PI * 880 * t) * 10000;
    int16_t stereo[2] = {s, s};
    i2s.write((uint8_t*)stereo, 4);
  }
}

void playChime(bool ascending) {
  const int sr = 44100;
  int notes[] = {523, 784, 1047};
  int durations[] = {180, 180, 500};
  for (int n = 0; n < 3; n++) {
    int idx = ascending ? n : (2 - n);
    int samples = sr * durations[n] / 1000;
    int fadeIn = samples / 12, fadeOut = samples / 2;
    for (int i = 0; i < samples; i++) {
      float t = (float)i / sr;
      float env = 1.0;
      if (i < fadeIn) env = (float)i / fadeIn;
      else if (i > samples - fadeOut) { float fp = (float)(samples - i) / fadeOut; env = fp * fp; }
      int16_t s = sin(2 * PI * notes[idx] * t) * 8000 * env;
      int16_t stereo[2] = {s, s};
      i2s.write((uint8_t*)stereo, 4);
    }
  }
}

String prettyTrackName(const String& path) {
  String s = path;
  if (s.startsWith("/")) s = s.substring(1);
  if (s.endsWith(".mp3") || s.endsWith(".MP3")) s = s.substring(0, s.length() - 4);
  return s;
}

String fitToWidth(const String& s, int maxWidth) {
  if (display.getStrWidth(s.c_str()) <= maxWidth) return s;
  String t = s;
  while (t.length() > 0 && display.getStrWidth((t + "...").c_str()) > maxWidth) t.remove(t.length() - 1);
  return t + "...";
}

void drawBootScreen(const char* msg) {
  display.clearBuffer();
  display.setFont(u8g2_font_helvB10_tr);
  display.drawStr(8, 24, "Retro Radio");
  display.setFont(u8g2_font_helvR08_tr);
  display.drawStr(8, 44, msg);
  display.sendBuffer();
}

void drawDisplay() {
  display.clearBuffer();
  display.setFont(u8g2_font_helvR08_tr);
  const char* modeName = (currentMode == MODE_MP3) ? "MP3" : (currentMode == MODE_BT) ? "BLUETOOTH" : (currentMode == MODE_RADIO) ? "RADIO" : "FM";
  display.drawStr(0, 8, modeName);

  const char* topRight = nullptr;
  bool muteState = (currentMode == MODE_FM) ? fmMuted : muted;
  if (muteState) topRight = "MUTED";
  else if (currentMode == MODE_MP3 && paused) topRight = "PAUSED";
  else if (currentMode == MODE_BT) {
    if (discoverable && !a2dp_sink.is_connected()) topRight = "PAIRING";
    else if (a2dp_sink.is_connected()) topRight = "CONNECTED";
  } else if (currentMode == MODE_RADIO) {
    if (paused) topRight = "PAUSED";
    else if (radioConnected) topRight = "LIVE";
    else topRight = "...";
  } else if (currentMode == MODE_FM) topRight = (fmAudioTaskHandle != NULL) ? "LIVE" : "NO CHIP";
  if (topRight) { int w = display.getStrWidth(topRight); display.drawStr(128 - w, 8, topRight); }
  display.drawHLine(0, 11, 128);

  if (currentMode == MODE_MP3) {
    if (trackCount == 0) display.drawStr(0, 30, "No tracks on SD");
    else {
      String name = prettyTrackName(tracks[currentTrack]);
      display.setFont(u8g2_font_helvB10_tr);
      display.drawStr(0, 26, fitToWidth(name, 128).c_str());
      display.setFont(u8g2_font_helvR08_tr);
      char info[16];
      snprintf(info, sizeof(info), "Track %d/%d", currentTrack + 1, trackCount);
      display.drawStr(0, 40, info);
    }
  } else if (currentMode == MODE_BT) {
    bool connected = a2dp_sink.is_connected();
    display.setFont(u8g2_font_helvB10_tr);
    if (connected) { display.drawStr(0, 26, "Connected"); display.setFont(u8g2_font_helvR08_tr); display.drawStr(0, 40, "Play music on phone"); }
    else if (discoverable) { display.drawStr(0, 26, "Pairing..."); display.setFont(u8g2_font_helvR08_tr); display.drawStr(0, 40, "Look for: RetroRadio"); }
    else { display.drawStr(0, 26, "Ready"); display.setFont(u8g2_font_helvR08_tr); display.drawStr(0, 40, "Press PAIR to pair"); }
  } else if (currentMode == MODE_RADIO) {
    display.setFont(u8g2_font_helvB10_tr);
    display.drawStr(0, 26, fitToWidth(stations[currentStation].name, 128).c_str());
    display.setFont(u8g2_font_helvR08_tr);
    char info[16];
    snprintf(info, sizeof(info), "Station %d/%d", currentStation + 1, NUM_STATIONS);
    display.drawStr(0, 40, info);
  } else if (currentMode == MODE_FM) {
    display.setFont(u8g2_font_helvB10_tr);
    char freqStr[16];
    snprintf(freqStr, sizeof(freqStr), "%.1f MHz", fmFrequencyMHz);
    display.drawStr(0, 26, freqStr);
    display.setFont(u8g2_font_helvR08_tr);
    display.drawStr(0, 40, "FM Radio");
  }

  display.setFont(u8g2_font_5x8_tr);
  display.drawStr(0, 62, "V");
  int volX = 8, volY = 56, volW = 120, volH = 6;
  display.drawFrame(volX, volY, volW, volH);
  float v = (currentMode == MODE_FM) ? (fmVolumeQ7 / 128.0) : vol;
  bool m = (currentMode == MODE_FM) ? fmMuted : muted;
  int volFill = m ? 0 : (int)(v * (volW - 2));
  if (volFill > 0) display.drawBox(volX + 1, volY + 1, volFill, volH - 2);
  display.sendBuffer();
}

void rebootIntoMode(Mode m) {
  Serial.print("Saving mode and rebooting into: ");
  switch (m) {
    case MODE_MP3: Serial.println("MP3"); break;
    case MODE_BT: Serial.println("BT"); break;
    case MODE_RADIO: Serial.println("RADIO"); break;
    case MODE_FM: Serial.println("FM"); break;
  }
  drawBootScreen("Switching mode...");
  prefs.begin("radio", false);
  prefs.putUChar("mode", (uint8_t)m);
  prefs.end();
  delay(200);
  ESP.restart();
}

void radioButtonPressed() {
  if (currentMode == MODE_RADIO) rebootIntoMode(MODE_FM);
  else rebootIntoMode(MODE_RADIO);
}

void cycleMode() {
  Mode next;
  switch (currentMode) {
    case MODE_MP3:   next = MODE_RADIO; break;
    case MODE_RADIO: next = MODE_MP3;   break;
    case MODE_BT:    next = MODE_MP3;   break;
    case MODE_FM:    next = MODE_MP3;   break;
    default:         next = MODE_MP3;   break;
  }
  rebootIntoMode(next);
}

void setupAudioToolsI2S() {
  i2sCfg = i2s.defaultConfig(TX_MODE);
  i2sCfg.pin_bck = I2S_BCLK; i2sCfg.pin_ws = I2S_LRC; i2sCfg.pin_data = I2S_DIN;
  i2sCfg.sample_rate = 44100; i2sCfg.channels = 2; i2sCfg.bits_per_sample = 16;
  i2sCfg.buffer_size = 1024; i2sCfg.buffer_count = 8;
  i2s.begin(i2sCfg);
}

void scanSD() {
  trackCount = 0;
  File root = SD.open("/");
  while (trackCount < 32) {
    File entry = root.openNextFile();
    if (!entry) break;
    String name = entry.name();
    if (!entry.isDirectory() && (name.endsWith(".mp3") || name.endsWith(".MP3"))) {
      int slash = name.lastIndexOf('/');
      String basename = (slash >= 0) ? name.substring(slash + 1) : name;
      if (basename.startsWith("._")) { entry.close(); continue; }
      tracks[trackCount++] = name.startsWith("/") ? name : ("/" + name);
    }
    entry.close();
  }
  root.close();
}

void playTrack(int idx, bool startPaused = false) {
  if (idx < 0 || idx >= trackCount) return;
  if (audioFile) audioFile.close();
  audioFile = SD.open(tracks[idx]);
  if (!audioFile) return;
  currentTrack = idx;
  paused = startPaused;
  Serial.print(startPaused ? "Loaded [" : "Playing [");
  Serial.print(idx); Serial.print("] "); Serial.println(tracks[idx]);
}

void nextTrack() { if (trackCount) playTrack((currentTrack + 1) % trackCount); }
void prevTrack() { if (trackCount) playTrack((currentTrack - 1 + trackCount) % trackCount); }

void setupMP3Mode() {
  Serial.println("--- MP3 mode ---");
  drawBootScreen("MP3 mode...");
  if (!SD.begin(SD_CS)) { drawBootScreen("SD card failed!"); return; }
  scanSD();
  setupAudioToolsI2S();
  auto vcfg = volume.defaultConfig();
  vcfg.copyFrom(i2sCfg);
  volume.begin(vcfg);
  volume.setVolume(vol);
  decoder.begin();
  if (trackCount > 0) playTrack(0, true);

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  setupEspNow();
}

void loopMP3Mode() {
  if (!paused && audioFile && audioFile.available()) copier.copy();
  else if (audioFile && !audioFile.available() && !paused) nextTrack();
}

void setupBTMode() {
  Serial.println("--- BT mode ---");
  drawBootScreen("BT mode...");
  setupAudioToolsI2S();
  a2dp_sink.set_on_connection_state_changed(onConnectionStateChanged);
  a2dp_sink.set_discoverability(ESP_BT_NON_DISCOVERABLE);
  a2dp_sink.start("RetroRadio");
  a2dp_sink.set_volume((uint8_t)(vol * 127));
}

void loopBTMode() {
  unsigned long now = millis();
  bool nowConnected = a2dp_sink.is_connected();
  if (connectEvent) {
    connectEvent = false; discoverable = false;
    a2dp_sink.set_discoverability(ESP_BT_NON_DISCOVERABLE);
    delay(200); playChime(true);
  }
  if (disconnectEvent) {
    disconnectEvent = false; delay(300);
    i2s.begin(i2sCfg); playChime(false);
  }
  if (discoverable && !nowConnected && now - lastBeep > BEEP_INTERVAL) {
    lastBeep = now; i2s.begin(i2sCfg); playBeep();
  }
}

void stopRadioStream() { if (radioConnected) { radioHttp.end(); radioConnected = false; } }

void startRadioStream() {
  stopRadioStream();
  Serial.print("Tuning: "); Serial.println(stations[currentStation].name);
  radioHttp.begin(radioClient, stations[currentStation].url);
  radioHttp.setReuse(true);
  radioHttp.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  int code = radioHttp.GET();
  if (code != HTTP_CODE_OK) { Serial.print("HTTP failed: "); Serial.println(code); radioHttp.end(); return; }
  radioConnected = true;
}

void nextStation() {
  currentStation = (currentStation + 1) % NUM_STATIONS;
  prefs.begin("radio", false); prefs.putInt("station", currentStation); prefs.end();
  startRadioStream();
}

void prevStation() {
  currentStation = (currentStation - 1 + NUM_STATIONS) % NUM_STATIONS;
  prefs.begin("radio", false); prefs.putInt("station", currentStation); prefs.end();
  startRadioStream();
}

void setVolume(int pct) {
  pct = constrain(pct, 0, 100);
  vol = pct / 100.0;
  if (currentMode == MODE_MP3 || currentMode == MODE_RADIO) { if (!muted) volume.setVolume(vol); }
  else if (currentMode == MODE_BT) { if (!muted) a2dp_sink.set_volume((uint8_t)(vol * 127)); }
  else if (currentMode == MODE_FM) fmVolumeQ7 = (pct * 128) / 100;
  Serial.print("Volume: "); Serial.println(pct);
}

void togglePause() {
  if (currentMode == MODE_MP3) paused = !paused;
  else if (currentMode == MODE_BT) {
    if (a2dp_sink.get_audio_state() == ESP_A2D_AUDIO_STATE_STARTED) a2dp_sink.pause();
    else a2dp_sink.play();
  } else if (currentMode == MODE_RADIO) paused = !paused;
  else if (currentMode == MODE_FM) fmMuted = !fmMuted;
}

void toggleMute() {
  if (currentMode == MODE_FM) { fmMuted = !fmMuted; return; }
  muted = !muted;
  if (currentMode == MODE_MP3 || currentMode == MODE_RADIO) volume.setVolume(muted ? 0 : vol);
  else if (currentMode == MODE_BT) a2dp_sink.set_volume(muted ? 0 : (uint8_t)(vol * 127));
}

void togglePairing() {
  if (currentMode != MODE_BT) return;
  discoverable = !discoverable;
  a2dp_sink.set_discoverability(discoverable ? ESP_BT_GENERAL_DISCOVERABLE : ESP_BT_NON_DISCOVERABLE);
}

void handleNext() {
  if (currentMode == MODE_MP3) nextTrack();
  else if (currentMode == MODE_BT) { if (a2dp_sink.is_connected()) btSendPassthrough(ESP_AVRC_PT_CMD_FORWARD); }
  else if (currentMode == MODE_RADIO) nextStation();
  else if (currentMode == MODE_FM) {
    fmFrequencyMHz = min(108.0f, fmFrequencyMHz + 0.1f);
    prefs.begin("radio", false); prefs.putFloat("fmFreq", fmFrequencyMHz); prefs.end();
  }
}

void handlePrev() {
  if (currentMode == MODE_MP3) prevTrack();
  else if (currentMode == MODE_BT) { if (a2dp_sink.is_connected()) btSendPassthrough(ESP_AVRC_PT_CMD_BACKWARD); }
  else if (currentMode == MODE_RADIO) prevStation();
  else if (currentMode == MODE_FM) {
    fmFrequencyMHz = max(87.5f, fmFrequencyMHz - 0.1f);
    prefs.begin("radio", false); prefs.putFloat("fmFreq", fmFrequencyMHz); prefs.end();
  }
}

String webPageHtml() {
  String html = "<!DOCTYPE html><html><head><meta charset='utf-8'>";
  html += "<meta name='viewport' content='width=device-width,initial-scale=1'>";
  html += "<title>Retro Radio</title>";
  html += "<style>";
  html += "body{font-family:-apple-system,system-ui,sans-serif;background:#1a1a1a;color:#eee;margin:0;padding:20px;max-width:480px;margin:auto}";
  html += "h1{font-size:20px;margin:0 0 16px;color:#f0c060}";
  html += ".card{background:#2a2a2a;border-radius:12px;padding:16px;margin-bottom:16px}";
  html += ".now{font-size:18px;font-weight:600;margin-bottom:6px}";
  html += ".mode{font-size:13px;color:#888;text-transform:uppercase;letter-spacing:1px}";
  html += ".meta{font-size:13px;color:#aaa;margin-top:6px}";
  html += ".row{display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap}";
  html += "button{background:#3a3a3a;color:#eee;border:none;border-radius:8px;padding:14px 16px;font-size:15px;cursor:pointer;flex:1;min-width:80px}";
  html += "button:hover{background:#4a4a4a}";
  html += "button.primary{background:#f0c060;color:#222;font-weight:600}";
  html += "button.danger{background:#c04040}";
  html += "select{background:#3a3a3a;color:#eee;border:none;border-radius:8px;padding:12px;font-size:15px;width:100%;margin-bottom:8px}";
  html += ".vol{font-size:13px;color:#888;margin-bottom:4px}";
  html += "</style></head><body>";
  html += "<h1>Retro Radio</h1>";
  html += "<div class='card'>";
  html += "<div class='mode' id='mode'>...</div>";
  html += "<div class='now' id='now'>Loading...</div>";
  html += "<div class='meta'><span id='meta'></span></div>";
  html += "<div class='vol' style='margin-top:10px'>Volume: <span id='volpct'>--</span>%</div>";
  html += "</div>";
  html += "<div class='card'>";
  html += "<div class='row'>";
  html += "<button onclick='cmd(\"prev\")'>&laquo; Prev</button>";
  html += "<button class='primary' onclick='cmd(\"play\")' id='playbtn'>Play/Pause</button>";
  html += "<button onclick='cmd(\"next\")'>Next &raquo;</button>";
  html += "</div>";
  html += "<div class='row'>";
  html += "<button onclick='cmd(\"voldn\")'>Vol -</button>";
  html += "<button onclick='cmd(\"mute\")'>Mute</button>";
  html += "<button onclick='cmd(\"volup\")'>Vol +</button>";
  html += "</div>";
  html += "<div class='row'>";
  html += "<button onclick='cmd(\"mode\")'>Switch Mode</button>";
  html += "</div>";
  html += "</div>";
  html += "<div class='card' id='picker'><div class='vol'>Loading list...</div></div>";
  html += "<script>";
  html += "async function cmd(c){await fetch('/cmd?c='+c);refresh()}";
  html += "async function pick(i){await fetch('/pick?i='+i);refresh()}";
  html += "async function refresh(){";
  html += "try{let r=await fetch('/state');let s=await r.json();";
  html += "document.getElementById('mode').textContent=s.modeName;";
  html += "document.getElementById('now').textContent=s.name||'(none)';";
  html += "let meta='';if(s.paused)meta+='PAUSED ';if(s.muted)meta+='MUTED';";
  html += "document.getElementById('meta').textContent=meta;";
  html += "document.getElementById('volpct').textContent=s.volume;";
  html += "let p=document.getElementById('picker');";
  html += "if(s.list && s.list.length){let h='<div class=\"vol\">'+s.listLabel+'</div>';";
  html += "for(let i=0;i<s.list.length;i++){let cls=(i==s.idx)?'primary':'';";
  html += "h+='<div class=\"row\"><button class=\"'+cls+'\" onclick=\"pick('+i+')\">'+s.list[i]+'</button></div>'}";
  html += "p.innerHTML=h}else{p.innerHTML='<div class=\"vol\">No list in this mode</div>'}";
  html += "}catch(e){console.log(e)}}";
  html += "refresh();setInterval(refresh,2000);";
  html += "</script></body></html>";
  return html;
}

void handleRoot()       { webServer.send(200, "text/html", webPageHtml()); }

void handleState() {
  String json = "{";
  const char* modeName = (currentMode == MODE_MP3) ? "MP3" : (currentMode == MODE_BT) ? "BLUETOOTH" : (currentMode == MODE_RADIO) ? "RADIO" : "FM";
  json += "\"modeName\":\""; json += modeName; json += "\",";
  String n = "";
  if (currentMode == MODE_MP3 && currentTrack >= 0 && currentTrack < trackCount) n = prettyTrackName(tracks[currentTrack]);
  else if (currentMode == MODE_RADIO) n = stations[currentStation].name;
  else if (currentMode == MODE_BT) n = a2dp_sink.is_connected() ? "Connected" : "Ready";
  else if (currentMode == MODE_FM) { char b[16]; snprintf(b, sizeof(b), "%.1f MHz", fmFrequencyMHz); n = b; }
  json += "\"name\":\""; json += n; json += "\",";
  int volPct = (currentMode == MODE_FM) ? (fmVolumeQ7 * 100 / 128) : (int)(vol * 100);
  bool mState = (currentMode == MODE_FM) ? fmMuted : muted;
  json += "\"volume\":"; json += volPct; json += ",";
  json += "\"paused\":"; json += (paused ? "true" : "false"); json += ",";
  json += "\"muted\":"; json += (mState ? "true" : "false"); json += ",";
  if (currentMode == MODE_RADIO) {
    json += "\"listLabel\":\"Stations\",";
    json += "\"idx\":"; json += currentStation; json += ",";
    json += "\"list\":[";
    for (int i = 0; i < NUM_STATIONS; i++) {
      json += "\""; json += stations[i].name; json += "\"";
      if (i < NUM_STATIONS - 1) json += ",";
    }
    json += "]";
  } else if (currentMode == MODE_MP3) {
    json += "\"listLabel\":\"Tracks\",";
    json += "\"idx\":"; json += currentTrack; json += ",";
    json += "\"list\":[";
    for (int i = 0; i < trackCount; i++) {
      json += "\""; json += prettyTrackName(tracks[i]); json += "\"";
      if (i < trackCount - 1) json += ",";
    }
    json += "]";
  } else {
    json += "\"list\":[]";
  }
  json += "}";
  webServer.send(200, "application/json", json);
}

void handleCmd() {
  if (!webServer.hasArg("c")) { webServer.send(400, "text/plain", "missing c"); return; }
  String c = webServer.arg("c");
  Serial.print("Web cmd: "); Serial.println(c);
  if      (c == "play")  togglePause();
  else if (c == "next")  handleNext();
  else if (c == "prev")  handlePrev();
  else if (c == "mute")  toggleMute();
  else if (c == "mode")  cycleMode();
  else if (c == "volup") {
    int p = (currentMode == MODE_FM) ? (fmVolumeQ7 * 100 / 128) : (int)(vol * 100);
    setVolume(p + 5);
  }
  else if (c == "voldn") {
    int p = (currentMode == MODE_FM) ? (fmVolumeQ7 * 100 / 128) : (int)(vol * 100);
    setVolume(p - 5);
  }
  broadcastState();
  webServer.send(200, "text/plain", "ok");
}

void handlePick() {
  if (!webServer.hasArg("i")) { webServer.send(400, "text/plain", "missing i"); return; }
  int i = webServer.arg("i").toInt();
  Serial.print("Web pick: "); Serial.println(i);
  if (currentMode == MODE_RADIO && i >= 0 && i < NUM_STATIONS) {
    currentStation = i;
    prefs.begin("radio", false); prefs.putInt("station", currentStation); prefs.end();
    startRadioStream();
  } else if (currentMode == MODE_MP3 && i >= 0 && i < trackCount) {
    playTrack(i);
  }
  broadcastState();
  webServer.send(200, "text/plain", "ok");
}

void startWebServer() {
  if (webServerRunning) return;
  webServer.on("/", handleRoot);
  webServer.on("/state", handleState);
  webServer.on("/cmd", handleCmd);
  webServer.on("/pick", handlePick);
  webServer.begin();
  webServerRunning = true;
  Serial.print("Web server up at http://");
  Serial.println(WiFi.localIP());
}

void setupRadioMode() {
  Serial.println("--- Internet Radio mode ---");
  drawBootScreen("Connecting Wi-Fi...");
  setupAudioToolsI2S();
  auto vcfg = volume.defaultConfig();
  vcfg.copyFrom(i2sCfg);
  volume.begin(vcfg);
  volume.setVolume(vol);
  decoder.begin();
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  unsigned long t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) delay(500);
  if (WiFi.status() != WL_CONNECTED) { drawBootScreen("Wi-Fi failed!"); return; }
  prefs.begin("radio", true);
  currentStation = prefs.getInt("station", 0);
  prefs.end();
  if (currentStation >= NUM_STATIONS) currentStation = 0;
  drawBootScreen("Tuning station...");
  startRadioStream();
  setupEspNow();
  startWebServer();
}

void loopRadioMode() {
  if (!radioConnected || paused) return;
  WiFiClient* stream = radioHttp.getStreamPtr();
  if (!stream) return;
  size_t avail = stream->available();
  if (avail == 0) return;
  size_t toRead = avail > sizeof(radioBuf) ? sizeof(radioBuf) : avail;
  int n = stream->read(radioBuf, toRead);
  if (n > 0) decoder.write(radioBuf, n);
}

bool tea5767Write(float freqMHz) {
  unsigned long freqHz = (unsigned long)(freqMHz * 1000000.0f);
  unsigned long pll = (4UL * (freqHz + 225000UL)) / 32768UL;
  uint8_t b[5];
  b[0] = (pll >> 8) & 0x3F; b[1] = pll & 0xFF;
  b[2] = 0x90; b[3] = 0x10; b[4] = 0x00;
  Wire.beginTransmission(TEA5767_ADDR);
  Wire.write(b, 5);
  return Wire.endTransmission() == 0;
}

void fmAudioTask(void* param) {
  esp_task_wdt_delete(NULL);
  vTaskDelay(1);
  const int chunkSamples = 256;
  static int16_t stereoBuf[256 * 2];
  const unsigned long intervalUs = 1000000 / FM_SAMPLE_RATE;
  unsigned long nextSampleTime = micros();
  int32_t dcAvgQ8 = 2048 << 8;
  while (true) {
    for (int i = 0; i < chunkSamples; i++) {
      while ((long)(micros() - nextSampleTime) < 0) {}
      nextSampleTime += intervalUs;
      int raw = adc1_get_raw(FM_ADC_CHANNEL);
      dcAvgQ8 -= dcAvgQ8 >> 12;
      dcAvgQ8 += raw >> 4;
      int dc = dcAvgQ8 >> 8;
      int16_t sample = 0;
      if (!fmMuted) {
        int32_t centred = (int32_t)raw - dc;
        int32_t scaled = centred * 32;
        scaled = (scaled * fmVolumeQ7) >> 7;
        if (scaled > 32767) scaled = 32767;
        if (scaled < -32768) scaled = -32768;
        sample = (int16_t)scaled;
      }
      stereoBuf[i*2] = sample;
      stereoBuf[i*2 + 1] = sample;
    }
    size_t written;
    i2s_write(I2S_NUM_0, stereoBuf, sizeof(stereoBuf), &written, portMAX_DELAY);
    long drift = (long)micros() - (long)nextSampleTime;
    if (drift > 50000 || drift < -50000) nextSampleTime = micros();
    taskYIELD();
  }
}

void setupFMMode() {
  Serial.println("--- FM mode ---");
  drawBootScreen("FM mode...");
  WiFi.disconnect(true);
  WiFi.persistent(false);
  WiFi.mode(WIFI_OFF);
  btStop();
  delay(200);
  i2s_driver_uninstall(I2S_NUM_0);
  delay(50);
  i2s_config_t cfg = {};
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX);
  cfg.sample_rate = FM_SAMPLE_RATE;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;
  cfg.communication_format = (i2s_comm_format_t)I2S_COMM_FORMAT_STAND_I2S;
  cfg.intr_alloc_flags = 0;
  cfg.dma_buf_count = 8;
  cfg.dma_buf_len = 256;
  cfg.use_apll = false;
  if (i2s_driver_install(I2S_NUM_0, &cfg, 0, NULL) != ESP_OK) { drawBootScreen("I2S fail!"); return; }
  i2s_pin_config_t pins = {};
  pins.bck_io_num = I2S_BCLK; pins.ws_io_num = I2S_LRC;
  pins.data_out_num = I2S_DIN; pins.data_in_num = I2S_PIN_NO_CHANGE;
  i2s_set_pin(I2S_NUM_0, &pins);
  adc1_config_width(ADC_WIDTH_BIT_12);
  adc1_config_channel_atten(FM_ADC_CHANNEL, ADC_ATTEN_DB_11);
  prefs.begin("radio", true);
  fmFrequencyMHz = prefs.getFloat("fmFreq", 90.9f);
  prefs.end();
  if (!tea5767Write(fmFrequencyMHz)) {
    Serial.println("TEA5767 not responding -- staying in FM mode, no audio");
    drawBootScreen("TEA5767 fail!");
    return;
  }
  Serial.print("Tuned to "); Serial.print(fmFrequencyMHz); Serial.println(" MHz");
  delay(200);
  xTaskCreatePinnedToCore(fmAudioTask, "fmAudio", 16384, NULL, 5, &fmAudioTaskHandle, 0);
  Serial.println("FM audio task started");
}

void loopFMMode() {
  if (fmAudioTaskHandle == NULL) return;
  unsigned long now = millis();
  if (now - lastStackCheck > STACK_CHECK_MS) {
    lastStackCheck = now;
    UBaseType_t hwm = uxTaskGetStackHighWaterMark(fmAudioTaskHandle);
    Serial.print("FM stack free: "); Serial.print((unsigned)hwm * sizeof(StackType_t));
    Serial.print(" heap: "); Serial.println(ESP.getFreeHeap());
  }
}

void handleButtonPress(const char* name) {
  Serial.print("Button: "); Serial.println(name);
  if (strcmp(name, "MP3") == 0) { if (currentMode != MODE_MP3) rebootIntoMode(MODE_MP3); }
  else if (strcmp(name, "BT") == 0) { if (currentMode != MODE_BT) rebootIntoMode(MODE_BT); }
  else if (strcmp(name, "RADIO") == 0) radioButtonPressed();
  else if (strcmp(name, "PAIR") == 0) togglePairing();
  else if (strcmp(name, "MUTE") == 0) toggleMute();
  else if (strcmp(name, "NEXT") == 0) handleNext();
  else if (strcmp(name, "PREV") == 0) handlePrev();
}

void pollButtons() {
  for (int i = 0; i < NUM_BUTTONS; i++) {
    bool state = digitalRead(buttons[i].pin);
    if (state != buttons[i].lastState && (millis() - buttons[i].lastChange) > 50) {
      buttons[i].lastChange = millis();
      if (state == LOW && buttons[i].lastState == HIGH) handleButtonPress(buttons[i].name);
      buttons[i].lastState = state;
    }
  }
}

void pollEncoder() {
  if (encoderDelta != 0) {
    noInterrupts();
    int delta = encoderDelta;
    encoderDelta = 0;
    interrupts();
    int curPct = (currentMode == MODE_FM) ? (fmVolumeQ7 * 100 / 128) : (int)(vol * 100);
    int newPct = constrain(curPct + delta * 5, 0, 100);
    setVolume(newPct);
  }
  bool btn = digitalRead(ENC_SW);
  if (btn != lastEncBtnState && (millis() - lastEncBtnChange) > 50) {
    lastEncBtnChange = millis();
    if (btn == LOW && lastEncBtnState == HIGH) togglePause();
    lastEncBtnState = btn;
  }
}

void handleRemoteCmd(uint8_t cmd) {
  Serial.print("Remote cmd: ");
  switch (cmd) {
    case CMD_PLAY: Serial.println("PLAY"); togglePause(); break;
    case CMD_VOLUP: {
      Serial.println("VOL+");
      int curPct = (currentMode == MODE_FM) ? (fmVolumeQ7 * 100 / 128) : (int)(vol * 100);
      setVolume(curPct + 5);
      break;
    }
    case CMD_VOLDN: {
      Serial.println("VOL-");
      int curPct = (currentMode == MODE_FM) ? (fmVolumeQ7 * 100 / 128) : (int)(vol * 100);
      setVolume(curPct - 5);
      break;
    }
    case CMD_NEXT: Serial.println("NEXT"); handleNext(); break;
    case CMD_MODE: Serial.println("MODE"); cycleMode(); break;
    case CMD_PREV: Serial.println("PREV"); handlePrev(); break;
    case CMD_MUTE: Serial.println("MUTE"); toggleMute(); break;
    default: Serial.print("unknown "); Serial.println(cmd); break;
  }
  broadcastState();
}

void setup() {
  Serial.begin(115200);
  delay(500);
  AudioLogger::instance().begin(Serial, AudioLogger::Error);
  Serial.print("Free heap at boot: "); Serial.println(ESP.getFreeHeap());

  Wire.begin(OLED_SDA, OLED_SCL);
  display.begin();
  display.setContrast(255);
  drawBootScreen("Booting...");

  prefs.begin("radio", true);
  currentMode = (Mode)prefs.getUChar("mode", (uint8_t)MODE_MP3);
  prefs.end();

  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENC_CLK), onEncoderTurn, FALLING);

  for (int i = 0; i < NUM_BUTTONS; i++) {
    int p = buttons[i].pin;
    if (p == 34 || p == 35 || p == 36 || p == 39) pinMode(p, INPUT);
    else pinMode(p, INPUT_PULLUP);
  }

  Serial.print("Boot mode: ");
  switch (currentMode) {
    case MODE_MP3: Serial.println("MP3"); setupMP3Mode(); break;
    case MODE_BT: Serial.println("BT"); setupBTMode(); break;
    case MODE_RADIO: Serial.println("RADIO"); setupRadioMode(); break;
    case MODE_FM: Serial.println("FM"); setupFMMode(); break;
  }

  delay(500);
  broadcastState();
}

void loop() {
  pollEncoder();
  pollButtons();

  if (pendingRemoteCmd != 0) {
    uint8_t cmd = pendingRemoteCmd;
    pendingRemoteCmd = 0;
    handleRemoteCmd(cmd);
  }

  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();
    if (cmd.startsWith("t") && currentMode == MODE_FM) {
      float f = cmd.substring(1).toFloat();
      if (f >= 87.5f && f <= 108.0f) {
        fmFrequencyMHz = f;
        tea5767Write(fmFrequencyMHz);
        prefs.begin("radio", false); prefs.putFloat("fmFreq", fmFrequencyMHz); prefs.end();
        Serial.print("Tuned to "); Serial.print(fmFrequencyMHz, 1); Serial.println(" MHz");
      }
    } else if (cmd.startsWith("s") && currentMode == MODE_RADIO) {
      int n = cmd.substring(1).toInt();
      if (n >= 1 && n <= NUM_STATIONS) { currentStation = n - 1; startRadioStream(); }
    }
  }

  switch (currentMode) {
    case MODE_MP3: loopMP3Mode(); break;
    case MODE_BT: loopBTMode(); break;
    case MODE_RADIO: loopRadioMode(); break;
    case MODE_FM: loopFMMode(); break;
  }

  if (webServerRunning) webServer.handleClient();

  if (currentMode != MODE_FM && millis() - lastStateBroadcast > STATE_BROADCAST_MS) {
    broadcastState();
  }

  unsigned long now = millis();
  if (now - lastDisplayRefresh > DISPLAY_REFRESH_MS) {
    lastDisplayRefresh = now;
    drawDisplay();
  }
}
