// ─────────────────────────────────────────────────────────────────────
// Retro Radio — MP3 + Bluetooth + Internet Radio
//
// Internet streaming uses standard Arduino HTTPClient + WiFiClient
// (instead of AudioTools' URLStream, which isn't reliably exposed in
// every version of the library). The audio bytes are read directly
// from the HTTP stream and fed into the existing MP3 decoder.
//
// HARDWARE: remove TEA5767 module + its passives. Encoder stays at
// CLK=27, DT=34, SW=15.  Edit WIFI_SSID and WIFI_PASSWORD below.
// ─────────────────────────────────────────────────────────────────────

#include <WiFi.h>
#include <HTTPClient.h>
#include "AudioTools.h"
#include "AudioTools/AudioCodecs/CodecMP3Helix.h"
#include "BluetoothA2DPSink.h"
#include <SPI.h>
#include <SD.h>
#include <math.h>
#include <Preferences.h>
#include <U8g2lib.h>

// ─── Wi-Fi credentials — EDIT THESE ──────────────────────────────────
#define WIFI_SSID     "MAKERSPACE"
#define WIFI_PASSWORD "12345678"

// ─── SD card (VSPI) ──────────────────────────────────────────────────
#define SD_CS    5
#define SD_MOSI  23
#define SD_MISO  19
#define SD_SCK   18

// ─── I2S amp ─────────────────────────────────────────────────────────
#define I2S_BCLK 13
#define I2S_LRC  14
#define I2S_DIN  12

// ─── Buttons ─────────────────────────────────────────────────────────
#define BTN_MP3      32
#define BTN_BT       25
#define BTN_RADIO    26
#define EXTRA_BUTTON 33      // BT pair / next station in radio mode

// ─── OLED SSD1309 ────────────────────────────────────────────────────
#define OLED_CS  17
#define OLED_DC  16
#define OLED_RES 4

// ─── Rotary encoder (rewired positions) ──────────────────────────────
#define ENC_CLK 27
#define ENC_DT  34
#define ENC_SW  15
#define VOL_STEP 0.05f

// ─── Modes ───────────────────────────────────────────────────────────
#define MODE_MP3   0
#define MODE_BT    1
#define MODE_RADIO 2

// ─── Audio plumbing (shared by all 3 modes) ──────────────────────────
I2SStream i2s;
VolumeStream volStream(i2s);
EncodedAudioStream decoder(&volStream, new MP3DecoderHelix());

// MP3 mode source
File audioFile;
StreamCopy copier(decoder, audioFile, 4096);

// Internet radio source — uses HTTPClient directly
HTTPClient http;
WiFiClient* radioClient = nullptr;

BluetoothA2DPSink a2dp_sink(i2s);
Preferences prefs;
I2SConfig i2sCfg;

// ─── OLED ────────────────────────────────────────────────────────────
U8G2_SSD1309_128X64_NONAME0_F_4W_HW_SPI display(
  U8G2_R0, /*cs=*/OLED_CS, /*dc=*/OLED_DC, /*reset=*/OLED_RES
);

// ─── Radio stations (HTTP MP3 streams only) ──────────────────────────
struct RadioStation {
  const char* name;
  const char* url;
};

const RadioStation stations[] = {
  {"Groove Salad",    "http://ice1.somafm.com/groovesalad-128-mp3"},
  {"Drone Zone",      "http://ice1.somafm.com/dronezone-128-mp3"},
  {"Indie Pop Rocks", "http://ice1.somafm.com/indiepop-128-mp3"},
  {"Lush",            "http://ice1.somafm.com/lush-128-mp3"},
  {"DEF Con Radio",   "http://ice1.somafm.com/defcon-128-mp3"},
  {"BBC World",       "http://stream.live.vc.bbcmedia.co.uk/bbc_world_service"},
};
const int NUM_STATIONS = sizeof(stations) / sizeof(stations[0]);
int currentStation = 0;
bool radioStreamActive = false;
bool radioPaused = false;

// ─── State ───────────────────────────────────────────────────────────
String tracks[20];
int trackCount = 0;
int currentTrack = 0;
float volume = 0.5;
bool paused = false;
bool discoverable = false;
volatile bool connectEvent = false;
volatile bool disconnectEvent = false;
unsigned long lastBtnPress = 0;
unsigned long lastBeep = 0;
unsigned long lastModeCheck = 0;
unsigned long lastEncCheck = 0;
unsigned long lastEncSwPress = 0;
unsigned long lastDisplayRefresh = 0;
int currentMode = MODE_MP3;

volatile int encoderDelta = 0;
volatile unsigned long lastEncIsrMs = 0;

// MP3 + BT track metadata
String   currentTitle      = "";
String   currentArtist     = "";
uint32_t currentBitrate    = 128000;
uint32_t currentDurationMs = 0;
uint32_t currentAudioStart = 0;
uint32_t currentFileSize   = 0;

volatile uint32_t btReportedPosMs = 0;
volatile uint32_t btReportTimeMs  = 0;
volatile bool     btPosKnown      = false;
volatile bool     btIsPlaying     = false;

#define DEBOUNCE_MS 500
#define BEEP_INTERVAL 1500
#define ENC_CHECK_INTERVAL_MS 20
#define DISPLAY_REFRESH_MS 250

// ─────────────────────────────────────────────────────────────────────
// Encoder ISR
// ─────────────────────────────────────────────────────────────────────

void IRAM_ATTR onEncoderCLK() {
  unsigned long now = millis();
  if (now - lastEncIsrMs < 2) return;
  lastEncIsrMs = now;
  if (digitalRead(ENC_DT) == HIGH) encoderDelta++;
  else encoderDelta--;
}

// ─────────────────────────────────────────────────────────────────────
// A2DP callbacks
// ─────────────────────────────────────────────────────────────────────

void onConnectionStateChanged(esp_a2d_connection_state_t state, void* obj) {
  if (state == ESP_A2D_CONNECTION_STATE_CONNECTED) connectEvent = true;
  else if (state == ESP_A2D_CONNECTION_STATE_DISCONNECTED) disconnectEvent = true;
}

void onAvrcMetadata(uint8_t id, const uint8_t* data) {
  String s = (const char*)data;
  switch (id) {
    case ESP_AVRC_MD_ATTR_TITLE:        currentTitle = s; break;
    case ESP_AVRC_MD_ATTR_ARTIST:       currentArtist = s; break;
    case ESP_AVRC_MD_ATTR_PLAYING_TIME: currentDurationMs = (uint32_t)s.toInt(); break;
  }
}

void onAvrcPlayPos(uint32_t playPos) {
  btReportedPosMs = playPos; btReportTimeMs = millis(); btPosKnown = true;
}
void onAvrcPlayStatus(esp_avrc_playback_stat_t status) {
  btIsPlaying = (status == ESP_AVRC_PLAYBACK_PLAYING);
  if (btPosKnown) btReportTimeMs = millis();
}

uint32_t btCurrentPositionMs() {
  if (!btPosKnown) return 0;
  if (!btIsPlaying) return btReportedPosMs;
  uint32_t elapsed = millis() - btReportTimeMs;
  uint32_t pos = btReportedPosMs + elapsed;
  if (currentDurationMs > 0 && pos > currentDurationMs) pos = currentDurationMs;
  return pos;
}

void btSendPassthrough(uint8_t cmd) {
  esp_avrc_ct_send_passthrough_cmd(0, cmd, ESP_AVRC_PT_CMD_STATE_PRESSED);
  esp_avrc_ct_send_passthrough_cmd(0, cmd, ESP_AVRC_PT_CMD_STATE_RELEASED);
}

// ─────────────────────────────────────────────────────────────────────
// ID3 + MP3-frame parsing
// ─────────────────────────────────────────────────────────────────────

static String cleanText(const uint8_t* data, uint32_t len) {
  String s = "";
  for (uint32_t i = 0; i < len; i++) if (data[i] >= 32 && data[i] < 127) s += (char)data[i];
  while (s.length() > 0 && s.charAt(s.length() - 1) == ' ') s.remove(s.length() - 1);
  return s;
}
static String decodeTextFrame(const uint8_t* data, uint32_t len) {
  if (len < 2) return "";
  uint8_t enc = data[0];
  if (enc == 0 || enc == 3) return cleanText(data + 1, len - 1);
  uint32_t start = 1;
  if (enc == 1 && len >= 3) start = 3;
  String s = "";
  for (uint32_t i = start; i + 1 < len; i += 2) {
    uint8_t b = data[i];
    if (b >= 32 && b < 127) s += (char)b;
  }
  while (s.length() > 0 && s.charAt(s.length() - 1) == ' ') s.remove(s.length() - 1);
  return s;
}
static uint32_t readFirstMP3Bitrate(File &f, uint32_t searchFrom) {
  static const int br_mpeg1_l3[16] = {0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0};
  static const int br_mpeg2_l3[16] = {0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,0};
  if (!f.seek(searchFrom)) return 0;
  int scanRemaining = 4096;
  uint8_t prev = 0, cur = 0;
  bool havePrev = false;
  while (scanRemaining-- > 0 && f.available() > 0) {
    int b = f.read();
    if (b < 0) break;
    cur = (uint8_t)b;
    if (havePrev && prev == 0xFF && (cur & 0xE0) == 0xE0) {
      uint8_t b2 = 0, b3 = 0;
      if (f.read(&b2, 1) != 1) return 0;
      if (f.read(&b3, 1) != 1) return 0;
      uint8_t versionBits = (cur >> 3) & 0x03;
      uint8_t layerBits = (cur >> 1) & 0x03;
      uint8_t bitrateIdx = (b2 >> 4) & 0x0F;
      if (layerBits == 0x01 && bitrateIdx > 0 && bitrateIdx < 15) {
        int kbps = (versionBits == 0x03) ? br_mpeg1_l3[bitrateIdx] : br_mpeg2_l3[bitrateIdx];
        if (kbps > 0) return (uint32_t)kbps * 1000;
      }
    }
    prev = cur;
    havePrev = true;
  }
  return 0;
}
void parseTrackMetadata(const String& path) {
  currentTitle = ""; currentArtist = "";
  currentBitrate = 128000; currentDurationMs = 0;
  currentAudioStart = 0; currentFileSize = 0;
  File f = SD.open(path);
  if (!f) return;
  currentFileSize = f.size();
  uint8_t hdr[10];
  if (f.read(hdr, 10) == 10 && hdr[0]=='I' && hdr[1]=='D' && hdr[2]=='3') {
    uint8_t majorVer = hdr[3];
    uint32_t tagSize = ((uint32_t)hdr[6]<<21)|((uint32_t)hdr[7]<<14)|((uint32_t)hdr[8]<<7)|(uint32_t)hdr[9];
    uint32_t pos = 10, endPos = 10 + tagSize;
    while (pos + 10 < endPos) {
      f.seek(pos);
      uint8_t fh[10];
      if (f.read(fh, 10) != 10) break;
      if (fh[0] == 0) break;
      char id[5] = { (char)fh[0], (char)fh[1], (char)fh[2], (char)fh[3], 0 };
      uint32_t frameSize;
      if (majorVer >= 4) {
        frameSize = ((uint32_t)fh[4]<<21)|((uint32_t)fh[5]<<14)|((uint32_t)fh[6]<<7)|(uint32_t)fh[7];
      } else {
        frameSize = ((uint32_t)fh[4]<<24)|((uint32_t)fh[5]<<16)|((uint32_t)fh[6]<<8)|(uint32_t)fh[7];
      }
      if (frameSize == 0 || frameSize > 4096) break;
      if (strcmp(id,"TIT2")==0 || strcmp(id,"TPE1")==0 || strcmp(id,"TLEN")==0) {
        uint8_t buf[256];
        uint32_t toRead = frameSize > sizeof(buf) ? sizeof(buf) : frameSize;
        if (f.read(buf, toRead) == (int)toRead) {
          String text = decodeTextFrame(buf, toRead);
          if      (strcmp(id,"TIT2")==0) currentTitle = text;
          else if (strcmp(id,"TPE1")==0) currentArtist = text;
          else if (strcmp(id,"TLEN")==0) currentDurationMs = (uint32_t)text.toInt();
        }
      }
      pos += 10 + frameSize;
    }
    currentAudioStart = 10 + tagSize;
  }
  uint32_t br = readFirstMP3Bitrate(f, currentAudioStart);
  if (br > 0) currentBitrate = br;
  if (currentDurationMs == 0 && currentBitrate > 0 && currentFileSize > currentAudioStart) {
    uint64_t audioBytes = currentFileSize - currentAudioStart;
    currentDurationMs = (uint32_t)((audioBytes * 8000ULL) / currentBitrate);
  }
  f.close();
}
uint32_t mp3CurrentPositionMs() {
  if (!audioFile || currentBitrate == 0) return 0;
  uint32_t filePos = audioFile.position();
  if (filePos <= currentAudioStart) return 0;
  uint32_t audioBytes = filePos - currentAudioStart;
  return (uint32_t)(((uint64_t)audioBytes * 8000ULL) / currentBitrate);
}

// ─────────────────────────────────────────────────────────────────────
// SD / MP3 playback
// ─────────────────────────────────────────────────────────────────────

void scanTracks() {
  File root = SD.open("/");
  trackCount = 0;
  while (true) {
    File entry = root.openNextFile();
    if (!entry) break;
    String name = entry.name();
    if (name.endsWith(".mp3") && !name.startsWith(".") && trackCount < 20) {
      tracks[trackCount++] = "/" + name;
    }
    entry.close();
  }
  root.close();
  Serial.print("Found tracks: "); Serial.println(trackCount);
}
void playTrack(int idx) {
  if (audioFile) audioFile.close();
  if (idx < 0) idx = trackCount - 1;
  if (idx >= trackCount) idx = 0;
  currentTrack = idx;
  parseTrackMetadata(tracks[idx]);
  audioFile = SD.open(tracks[idx]);
  if (audioFile && currentAudioStart > 0) audioFile.seek(currentAudioStart);
  Serial.print("Playing: "); Serial.println(tracks[idx]);
}

// ─────────────────────────────────────────────────────────────────────
// Tones
// ─────────────────────────────────────────────────────────────────────

void playBeep() {
  const int sr = 44100;
  int samples = sr * 200 / 1000;
  for (int i = 0; i < samples; i++) {
    float t = (float)i / sr;
    int16_t sample = sin(2 * PI * 880 * t) * 10000;
    int16_t stereo[2] = {sample, sample};
    i2s.write((uint8_t*)stereo, 4);
  }
}
void playChime(bool ascending) {
  const int sr = 44100;
  int notes[] = {523, 784, 1047};
  int durations[] = {180, 180, 500};
  for (int n = 0; n < 3; n++) {
    int idx = ascending ? n : (2 - n);
    int samples = sr * durations[n] / 1000;
    int fadeIn = samples / 12, fadeOut = samples / 2;
    for (int i = 0; i < samples; i++) {
      float t = (float)i / sr;
      float envelope = 1.0;
      if (i < fadeIn) envelope = (float)i / fadeIn;
      else if (i > samples - fadeOut) {
        float fp = (float)(samples - i) / fadeOut;
        envelope = fp * fp;
      }
      int16_t sample = sin(2 * PI * notes[idx] * t) * 8000 * envelope;
      int16_t stereo[2] = {sample, sample};
      i2s.write((uint8_t*)stereo, 4);
    }
  }
}

// ─────────────────────────────────────────────────────────────────────
// Mode switching
// ─────────────────────────────────────────────────────────────────────

void switchMode(int newMode) {
  Serial.print("Switching to mode "); Serial.println(newMode);
  prefs.begin("radio", false);
  prefs.putInt("mode", newMode);
  prefs.end();
  delay(200);
  ESP.restart();
}

// ─────────────────────────────────────────────────────────────────────
// Volume + encoder
// ─────────────────────────────────────────────────────────────────────

void applyVolume(float v) {
  if (v < 0.0f) v = 0.0f;
  if (v > 1.0f) v = 1.0f;
  volume = v;
  volStream.setVolume(volume);
  if (currentMode == MODE_BT) a2dp_sink.set_volume((uint8_t)(volume * 127.0f));
}

void handleEncoder() {
  int delta;
  noInterrupts();
  delta = encoderDelta;
  encoderDelta = 0;
  interrupts();
  if (delta != 0) applyVolume(volume + delta * VOL_STEP);
}

void handleEncoderButton() {
  if (digitalRead(ENC_SW) != LOW) return;
  if (millis() - lastEncSwPress <= DEBOUNCE_MS) return;
  lastEncSwPress = millis();

  if (currentMode == MODE_MP3) {
    paused = !paused;
    Serial.println(paused ? "MP3 paused" : "MP3 playing");
  } else if (currentMode == MODE_BT) {
    if (!a2dp_sink.is_connected()) { Serial.println("BT not connected"); return; }
    btSendPassthrough(btIsPlaying ? ESP_AVRC_PT_CMD_PAUSE : ESP_AVRC_PT_CMD_PLAY);
  } else if (currentMode == MODE_RADIO) {
    radioPaused = !radioPaused;
    Serial.println(radioPaused ? "Radio paused" : "Radio playing");
  }
}

// ─────────────────────────────────────────────────────────────────────
// Radio helpers — HTTP streaming
// ─────────────────────────────────────────────────────────────────────

bool radioConnectStation(int idx) {
  if (idx < 0) idx = NUM_STATIONS - 1;
  if (idx >= NUM_STATIONS) idx = 0;
  currentStation = idx;

  Serial.print("Tuning: "); Serial.println(stations[idx].name);

  // Close any existing connection
  if (radioClient) {
    http.end();
    radioClient = nullptr;
  }
  radioStreamActive = false;

  http.setUserAgent("RetroRadio/1.0");
  http.setReuse(false);
  http.setTimeout(8000);

  if (!http.begin(stations[idx].url)) {
    Serial.println("http.begin failed");
    return false;
  }

  int code = http.GET();
  if (code != HTTP_CODE_OK && code != 200) {
    Serial.print("HTTP code: "); Serial.println(code);
    http.end();
    return false;
  }

  radioClient = http.getStreamPtr();
  if (!radioClient) {
    Serial.println("getStreamPtr returned null");
    http.end();
    return false;
  }

  radioStreamActive = true;
  radioPaused = false;
  Serial.println("Stream open");

  prefs.begin("radio", false);
  prefs.putInt("station", currentStation);
  prefs.end();

  return true;
}

void radioNext() { radioConnectStation(currentStation + 1); }
void radioPrev() { radioConnectStation(currentStation - 1); }

// ─────────────────────────────────────────────────────────────────────
// OLED
// ─────────────────────────────────────────────────────────────────────

String prettyTrackName(const String& path) {
  String s = path;
  if (s.startsWith("/")) s = s.substring(1);
  if (s.endsWith(".mp3") || s.endsWith(".MP3")) s = s.substring(0, s.length() - 4);
  return s;
}
String fitToWidth(const String& s, int maxWidth) {
  if (display.getStrWidth(s.c_str()) <= maxWidth) return s;
  String t = s;
  while (t.length() > 0 && display.getStrWidth((t + "...").c_str()) > maxWidth) {
    t.remove(t.length() - 1);
  }
  return t + "...";
}
void formatTime(uint32_t ms, char* out, size_t outSize) {
  uint32_t totalSec = ms / 1000;
  uint32_t mins = totalSec / 60;
  uint32_t secs = totalSec % 60;
  if (mins > 99) mins = 99;
  snprintf(out, outSize, "%lu:%02lu", (unsigned long)mins, (unsigned long)secs);
}
void drawTitleArtist(int titleBaseline, int artistBaseline, const String& title, const String& artist) {
  display.setFont(u8g2_font_helvB10_tr);
  display.drawStr(0, titleBaseline, fitToWidth(title, 128).c_str());
  if (artist.length() > 0) {
    display.setFont(u8g2_font_helvR08_tr);
    display.drawStr(0, artistBaseline, fitToWidth(artist, 128).c_str());
  }
}
void drawProgressRow(uint32_t posMs, uint32_t durMs) {
  display.setFont(u8g2_font_helvR08_tr);
  char tposBuf[8], tdurBuf[8];
  formatTime(posMs, tposBuf, sizeof(tposBuf));
  int wPos = display.getStrWidth(tposBuf);
  display.drawStr(0, 47, tposBuf);
  if (durMs == 0) return;
  formatTime(durMs, tdurBuf, sizeof(tdurBuf));
  int wDur = display.getStrWidth(tdurBuf);
  display.drawStr(128 - wDur, 47, tdurBuf);
  int barX = wPos + 4, barW = 128 - wPos - wDur - 8, barY = 42;
  if (barW > 10) {
    display.drawFrame(barX, barY, barW, 5);
    int fill = (int)((float)posMs / (float)durMs * (barW - 2));
    if (fill < 0) fill = 0;
    if (fill > barW - 2) fill = barW - 2;
    if (fill > 0) display.drawBox(barX + 1, barY + 1, fill, 3);
  }
}

void drawDisplay() {
  display.clearBuffer();

  display.setFont(u8g2_font_helvR08_tr);
  const char* modeName =
    (currentMode == MODE_MP3) ? "MP3" :
    (currentMode == MODE_BT)  ? "BLUETOOTH" : "RADIO";
  display.drawStr(0, 8, modeName);

  const char* topRight = nullptr;
  if (currentMode == MODE_MP3 && paused) topRight = "PAUSED";
  else if (currentMode == MODE_BT) {
    if (discoverable && !a2dp_sink.is_connected()) topRight = "PAIRING";
    else if (a2dp_sink.is_connected() && !btIsPlaying && currentTitle.length() > 0) topRight = "PAUSED";
  } else if (currentMode == MODE_RADIO) {
    if (WiFi.status() != WL_CONNECTED) topRight = "NO WIFI";
    else if (radioPaused) topRight = "PAUSED";
    else if (!radioStreamActive) topRight = "CONNECTING";
  }
  if (topRight) {
    int w = display.getStrWidth(topRight);
    display.drawStr(128 - w, 8, topRight);
  }
  display.drawHLine(0, 11, 128);

  if (currentMode == MODE_MP3) {
    if (trackCount == 0) {
      display.setFont(u8g2_font_helvR08_tr);
      display.drawStr(0, 30, "No tracks on SD");
    } else {
      String t = currentTitle.length() > 0 ? currentTitle : prettyTrackName(tracks[currentTrack]);
      drawTitleArtist(24, 35, t, currentArtist);
      uint32_t posMs = mp3CurrentPositionMs();
      if (currentDurationMs > 0 && posMs > currentDurationMs) posMs = currentDurationMs;
      drawProgressRow(posMs, currentDurationMs);
    }
  } else if (currentMode == MODE_BT) {
    bool connected = a2dp_sink.is_connected();
    if (connected && currentTitle.length() > 0) {
      drawTitleArtist(24, 35, currentTitle, currentArtist);
      drawProgressRow(btCurrentPositionMs(), currentDurationMs);
    } else if (connected) {
      display.setFont(u8g2_font_helvB10_tr);
      display.drawStr(0, 28, "Connected");
      display.setFont(u8g2_font_helvR08_tr);
      display.drawStr(0, 42, "Press play on phone");
    } else if (discoverable) {
      display.setFont(u8g2_font_helvB10_tr);
      display.drawStr(0, 28, "Pairing…");
      display.setFont(u8g2_font_helvR08_tr);
      display.drawStr(0, 42, "Look for: Retro Radio");
    } else {
      display.setFont(u8g2_font_helvB10_tr);
      display.drawStr(0, 28, "Ready");
      display.setFont(u8g2_font_helvR08_tr);
      display.drawStr(0, 42, "Press pair to discover");
    }
  } else {  // MODE_RADIO
    display.setFont(u8g2_font_helvB10_tr);
    display.drawStr(0, 28, fitToWidth(stations[currentStation].name, 128).c_str());
    display.setFont(u8g2_font_helvR08_tr);
    char info[40];
    snprintf(info, sizeof(info), "Station %d / %d", currentStation + 1, NUM_STATIONS);
    display.drawStr(0, 42, info);
  }

  display.setFont(u8g2_font_helvR08_tr);
  display.drawStr(0, 63, "Vol");
  int volX = 22, volY = 56, volW = 106, volH = 7;
  display.drawFrame(volX, volY, volW, volH);
  int volFill = (int)(volume * (volW - 2));
  if (volFill > 0) display.drawBox(volX + 1, volY + 1, volFill, volH - 2);

  display.sendBuffer();
}

// ─────────────────────────────────────────────────────────────────────
// Mode setup / loops
// ─────────────────────────────────────────────────────────────────────

void setupMP3() {
  Serial.println("MP3 MODE");
  decoder.begin();
  if (trackCount > 0) playTrack(0);
}

void setupBluetooth() {
  Serial.println("BLUETOOTH MODE");
  a2dp_sink.set_on_connection_state_changed(onConnectionStateChanged);
  a2dp_sink.set_avrc_metadata_callback(onAvrcMetadata);
  a2dp_sink.set_avrc_rn_play_pos_callback(onAvrcPlayPos, 1);
  a2dp_sink.set_avrc_rn_playstatus_callback(onAvrcPlayStatus);
  a2dp_sink.set_discoverability(ESP_BT_NON_DISCOVERABLE);
  a2dp_sink.start("Retro Radio");
  a2dp_sink.set_volume((uint8_t)(volume * 127.0f));
}

void setupRadio() {
  Serial.println("INTERNET RADIO MODE");

  prefs.begin("radio", true);
  currentStation = prefs.getInt("station", 0);
  prefs.end();
  if (currentStation < 0 || currentStation >= NUM_STATIONS) currentStation = 0;

  display.clearBuffer();
  display.setFont(u8g2_font_helvB10_tr);
  display.drawStr(4, 28, "Radio");
  display.setFont(u8g2_font_helvR08_tr);
  display.drawStr(4, 44, "Connecting to Wi-Fi…");
  display.sendBuffer();

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Wi-Fi");
  int waited = 0;
  while (WiFi.status() != WL_CONNECTED && waited < 20000) {
    delay(250);
    waited += 250;
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Wi-Fi failed");
    return;
  }
  Serial.print("Wi-Fi OK, IP "); Serial.println(WiFi.localIP());

  decoder.begin();
  radioConnectStation(currentStation);
}

void loopMP3() {
  if (!paused) copier.copy();
  if (audioFile && !audioFile.available() && !paused) playTrack(currentTrack + 1);
  if (Serial.available()) {
    char cmd = Serial.read();
    if (cmd == 'n') playTrack(currentTrack + 1);
    else if (cmd == 'p') playTrack(currentTrack - 1);
    else if (cmd == 's') paused = !paused;
    else if (cmd == '+') applyVolume(volume + 0.1f);
    else if (cmd == '-') applyVolume(volume - 0.1f);
  }
}

void loopBluetooth() {
  unsigned long now = millis();
  bool nowConnected = a2dp_sink.is_connected();

  if (connectEvent) {
    connectEvent = false;
    Serial.println("BT CONNECTED");
    discoverable = false;
    a2dp_sink.set_discoverability(ESP_BT_NON_DISCOVERABLE);
    currentTitle = ""; currentArtist = ""; currentDurationMs = 0;
    btPosKnown = false; btReportedPosMs = 0; btIsPlaying = false;
    delay(200);
    playChime(true);
  }
  if (disconnectEvent) {
    disconnectEvent = false;
    Serial.println("BT DISCONNECTED");
    currentTitle = ""; currentArtist = ""; currentDurationMs = 0;
    btPosKnown = false; btReportedPosMs = 0; btIsPlaying = false;
    delay(300);
    i2s.begin(i2sCfg);
    playChime(false);
  }

  if (!digitalRead(EXTRA_BUTTON) && now - lastBtnPress > DEBOUNCE_MS) {
    lastBtnPress = now;
    discoverable = !discoverable;
    if (discoverable) {
      a2dp_sink.set_discoverability(ESP_BT_GENERAL_DISCOVERABLE);
      Serial.println("Pairing ON");
    } else {
      a2dp_sink.set_discoverability(ESP_BT_NON_DISCOVERABLE);
      Serial.println("Pairing OFF");
    }
  }

  if (discoverable && !nowConnected && now - lastBeep > BEEP_INTERVAL) {
    lastBeep = now;
    i2s.begin(i2sCfg);
    playBeep();
  }
}

void loopRadio() {
  if (WiFi.status() != WL_CONNECTED) return;

  // Pump bytes from the HTTP stream into the MP3 decoder
  if (radioStreamActive && !radioPaused && radioClient && radioClient->available()) {
    uint8_t buf[1024];
    int n = radioClient->read(buf, sizeof(buf));
    if (n > 0) {
      decoder.write(buf, n);
    }
  }

  // Detect stream death: if the connection's gone, try to reconnect
  if (radioStreamActive && !radioPaused && radioClient && !radioClient->connected()) {
    Serial.println("Stream disconnected, reconnecting…");
    radioConnectStation(currentStation);
  }

  // EXTRA_BUTTON → next station
  unsigned long now = millis();
  if (!digitalRead(EXTRA_BUTTON) && now - lastBtnPress > DEBOUNCE_MS) {
    lastBtnPress = now;
    radioNext();
  }

  // Serial commands
  if (Serial.available()) {
    char cmd = Serial.read();
    if (cmd == 'n') radioNext();
    else if (cmd == 'p') radioPrev();
    else if (cmd == 's') radioPaused = !radioPaused;
    else if (cmd == '+') applyVolume(volume + 0.1f);
    else if (cmd == '-') applyVolume(volume - 0.1f);
  }
}

// ─────────────────────────────────────────────────────────────────────
// Arduino entry points
// ─────────────────────────────────────────────────────────────────────

void setup() {
  Serial.begin(115200);
  delay(2000);
  AudioLogger::instance().begin(Serial, AudioLogger::Warning);

  pinMode(BTN_MP3, INPUT_PULLUP);
  pinMode(BTN_BT, INPUT_PULLUP);
  pinMode(BTN_RADIO, INPUT_PULLUP);
  pinMode(EXTRA_BUTTON, INPUT_PULLUP);

  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT,  INPUT_PULLUP);
  pinMode(ENC_SW,  INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENC_CLK), onEncoderCLK, FALLING);

  prefs.begin("radio", true);
  currentMode = prefs.getInt("mode", MODE_MP3);
  prefs.end();

  SPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS);
  if (!SD.begin(SD_CS)) Serial.println("SD failed");
  else scanTracks();

  display.begin();
  display.setContrast(255);
  display.clearBuffer();
  display.setFont(u8g2_font_helvB10_tr);
  display.drawStr(4, 30, "Retro Radio");
  display.drawStr(4, 48, "Booting…");
  display.sendBuffer();

  i2sCfg = i2s.defaultConfig(TX_MODE);
  i2sCfg.pin_bck  = I2S_BCLK;
  i2sCfg.pin_ws   = I2S_LRC;
  i2sCfg.pin_data = I2S_DIN;
  i2sCfg.buffer_size = 1024;
  i2sCfg.buffer_count = 8;
  i2sCfg.sample_rate = 44100;
  i2sCfg.channels = 2;
  i2sCfg.bits_per_sample = 16;
  i2s.begin(i2sCfg);

  auto vcfg = volStream.defaultConfig();
  vcfg.copyFrom(i2sCfg);
  volStream.begin(vcfg);

  applyVolume(0.5f);

  if (currentMode == MODE_MP3)        setupMP3();
  else if (currentMode == MODE_BT)    setupBluetooth();
  else if (currentMode == MODE_RADIO) setupRadio();
}

void loop() {
  unsigned long now = millis();

  if (now - lastModeCheck > 200) {
    lastModeCheck = now;
    if (!digitalRead(BTN_MP3)   && currentMode != MODE_MP3)   switchMode(MODE_MP3);
    if (!digitalRead(BTN_BT)    && currentMode != MODE_BT)    switchMode(MODE_BT);
    if (!digitalRead(BTN_RADIO) && currentMode != MODE_RADIO) switchMode(MODE_RADIO);
  }

  if (now - lastEncCheck > ENC_CHECK_INTERVAL_MS) {
    lastEncCheck = now;
    handleEncoder();
    handleEncoderButton();
  }

  if (now - lastDisplayRefresh > DISPLAY_REFRESH_MS) {
    lastDisplayRefresh = now;
    drawDisplay();
  }

  if (currentMode == MODE_MP3)        loopMP3();
  else if (currentMode == MODE_BT)    loopBluetooth();
  else if (currentMode == MODE_RADIO) loopRadio();
}
